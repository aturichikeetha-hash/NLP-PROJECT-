import React, { useState, useEffect } from 'react';
import { 
  Briefcase, 
  TrendingUp, 
  Award, 
  GraduationCap, 
  DollarSign, 
  CheckCircle, 
  Sparkles,
  Layers,
  ArrowRight
} from 'lucide-react';
import { api } from '../services/api';

export default function CareerGuidance() {
  const [careerPaths, setCareerPaths] = useState([]);
  const [selectedProgramId, setSelectedProgramId] = useState('PROG-BTECH-CSE');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchCareers();
  }, []);

  const fetchCareers = async () => {
    setLoading(true);
    try {
      const data = await api.getAllCareers();
      setCareerPaths(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const currentPath = careerPaths.find(c => c.program_id === selectedProgramId) || careerPaths[0];

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Briefcase className="w-6 h-6 text-sky-400" />
            AI Career Guidance & Industry Pathway Engine
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Explore industry demand trends, salary benchmarks, in-demand technical competencies, and professional certification roadmaps
          </p>
        </div>
      </div>

      {/* Program Selector Pills */}
      <div className="flex flex-wrap gap-2 pb-2 border-b border-slate-800">
        {careerPaths.map((cp) => (
          <button
            key={cp.program_id}
            onClick={() => setSelectedProgramId(cp.program_id)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              selectedProgramId === cp.program_id
                ? 'bg-sky-600 text-white shadow-md shadow-sky-600/20'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            {cp.program_name} ({cp.degree})
          </button>
        ))}
      </div>

      {currentPath && (
        <div className="space-y-6">
          
          {/* Top Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-2">
              <div className="text-xs text-slate-400 flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <span>Industry Demand Growth</span>
              </div>
              <div className="text-xl font-bold text-white">
                {currentPath.industry_demand}
              </div>
              <p className="text-xs text-slate-400">
                High recruitment velocity in enterprise tech & research labs
              </p>
            </div>

            <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-2">
              <div className="text-xs text-slate-400 flex items-center gap-1.5">
                <DollarSign className="w-4 h-4 text-sky-400" />
                <span>Entry-Level (Fresher) CTC</span>
              </div>
              <div className="text-xl font-bold text-sky-400 font-mono">
                {currentPath.fresher_salary_range}
              </div>
              <p className="text-xs text-slate-400">
                Campus placements and premier product firm packages
              </p>
            </div>

            <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-2">
              <div className="text-xs text-slate-400 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span>Mid-Career Salary Potential</span>
              </div>
              <div className="text-xl font-bold text-purple-400 font-mono">
                {currentPath.mid_salary_range}
              </div>
              <p className="text-xs text-slate-400">
                After 3-5 years of industry specialization
              </p>
            </div>

          </div>

          {/* Core Roles & In-Demand Competencies */}
          <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-sky-400" />
              Primary Career Profiles & Required Tech Stack
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
              {currentPath.primary_career_roles?.map((role, idx) => (
                <div key={idx} className="bg-slate-900/90 p-4 rounded-xl border border-slate-800 space-y-3 flex flex-col justify-between">
                  <div>
                    <h4 className="text-sm font-bold text-white">{role.title}</h4>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                      {role.description}
                    </p>
                  </div>
                  <div>
                    <div className="text-[10px] uppercase font-bold text-slate-400 mb-1.5">
                      Core Skills:
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {role.key_skills?.map((sk, sIdx) => (
                        <span key={sIdx} className="text-[11px] px-2 py-0.5 rounded bg-slate-800 text-sky-300">
                          {sk}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Higher Education & Recommended Certifications */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-indigo-400" />
                Higher Education & Research Pathways
              </h3>
              <ul className="space-y-2 pt-1">
                {currentPath.higher_education_options?.map((opt, idx) => (
                  <li key={idx} className="text-xs text-slate-200 flex items-start gap-2 bg-slate-900/60 p-3 rounded-xl border border-slate-800/80">
                    <ArrowRight className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                    <span>{opt}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-400" />
                Recommended Global Industry Certifications
              </h3>
              <ul className="space-y-2 pt-1">
                {currentPath.recommended_certifications?.map((cert, idx) => (
                  <li key={idx} className="text-xs text-slate-200 flex items-start gap-2 bg-slate-900/60 p-3 rounded-xl border border-slate-800/80">
                    <CheckCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <span>{cert}</span>
                  </li>
                ))}
              </ul>
            </div>

          </div>

        </div>
      )}

    </div>
  );
}

