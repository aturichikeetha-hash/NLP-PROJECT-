import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Sparkles, 
  Sliders, 
  BookOpen, 
  RefreshCw, 
  GraduationCap, 
  CheckCircle,
  HelpCircle
} from 'lucide-react';
import { api } from '../services/api';
import XAIExplanationCard from '../components/XAIExplanationCard';

export default function EligibilityChecker({ userProfile }) {
  const [colleges, setColleges] = useState([]);
  const [selectedProgramId, setSelectedProgramId] = useState('PROG-BTECH-CSE');
  const [selectedCollegeId, setSelectedCollegeId] = useState('COL-001');
  
  // Sandbox parameters (initialized from user profile)
  const [twelfthPct, setTwelfthPct] = useState(userProfile?.twelfth_percentage || 85.5);
  const [ugCgpa, setUgCgpa] = useState(userProfile?.ug_cgpa || 8.2);
  const [ugDegree, setUgDegree] = useState(userProfile?.ug_degree || 'B.Sc Mathematics');
  const [category, setCategory] = useState(userProfile?.reservation_category || 'General');
  const [percentile, setPercentile] = useState(userProfile?.entrance_percentile || 93.8);
  const [isPwd, setIsPwd] = useState(userProfile?.is_pwd || false);
  const [subjects, setSubjects] = useState(userProfile?.subjects_studied || ['Physics', 'Mathematics', 'Chemistry']);

  const [decision, setDecision] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadColleges();
  }, []);

  useEffect(() => {
    runEligibilityCheck();
  }, [selectedProgramId, selectedCollegeId, twelfthPct, ugCgpa, ugDegree, category, percentile, isPwd, subjects]);

  const loadColleges = async () => {
    try {
      const data = await api.getColleges();
      setColleges(data);
    } catch (err) {
      console.error(err);
    }
  };

  const runEligibilityCheck = async () => {
    setLoading(true);
    try {
      const payload = {
        program_id: selectedProgramId,
        college_id: selectedCollegeId,
        twelfth_percentage: Number(twelfthPct),
        ug_cgpa: Number(ugCgpa),
        ug_degree: ugDegree,
        reservation_category: category,
        entrance_percentile: Number(percentile),
        is_pwd: isPwd,
        subjects_studied: subjects
      };
      const res = await api.evaluateEligibility(payload);
      setDecision(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const toggleSubject = (sub) => {
    setSubjects(prev => 
      prev.includes(sub) ? prev.filter(s => s !== sub) : [...prev, sub]
    );
  };

  const allAvailableSubjects = ['Physics', 'Mathematics', 'Chemistry', 'Computer Science', 'Statistics', 'Biology', 'Electronics'];

  return (
    <div className="space-y-6">
      
      {/* Page Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-sky-400" />
            AI Admission Eligibility & Explainable AI (XAI) Engine
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time rule-based verification with statutory quota relaxations and transparent attribution reasoning
          </p>
        </div>
      </div>

      {/* Program Selection & Interactive Sandbox Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Program Selection & Profile Overrides */}
        <div className="lg:col-span-4 space-y-4">
          <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-4">
            
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Sliders className="w-4 h-4 text-sky-400" />
                Target Program & Sandbox
              </h3>
              <span className="text-[10px] uppercase font-bold text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded">
                Live Simulator
              </span>
            </div>

            {/* Target Program Select */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Select Academic Program</label>
              <select
                value={selectedProgramId}
                onChange={(e) => setSelectedProgramId(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-sky-500"
              >
                <optgroup label="Undergraduate (B.Tech & B.Sc)">
                  <option value="PROG-BTECH-CSE">B.Tech - Computer Science & Eng. (COL-001)</option>
                  <option value="PROG-BTECH-AIDS">B.Tech - AI & Data Science (COL-001)</option>
                  <option value="PROG-BTECH-ECE">B.Tech - Electronics & Comm. (COL-001)</option>
                  <option value="PROG-BTECH-MECH">B.Tech - Mechanical & Robotics (COL-003)</option>
                  <option value="PROG-BSC-DATA">B.Sc (Hons) - Data Science & AI (COL-003)</option>
                </optgroup>
                <optgroup label="Postgraduate (MCA, MBA, M.Tech)">
                  <option value="PROG-MCA">Master of Computer Applications (MCA) (COL-002)</option>
                  <option value="PROG-MBA-TECH">MBA in Technology & Analytics (COL-002)</option>
                  <option value="PROG-MTECH-CSE">M.Tech in Computer Science (COL-002)</option>
                </optgroup>
              </select>
            </div>

            {/* Reservation Category */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">Reservation Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-sky-500"
              >
                <option value="General">General / Open (UR)</option>
                <option value="OBC-NCL">OBC-NCL (27% Central Quota)</option>
                <option value="EWS">EWS (10% Income &lt; 8 LPA Quota)</option>
                <option value="SC">Scheduled Castes - SC (15% Quota)</option>
                <option value="ST">Scheduled Tribes - ST (7.5% Quota)</option>
              </select>
            </div>

            {/* Entrance Exam Percentile Slider */}
            <div className="space-y-2">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-300">Entrance Score / Percentile</span>
                <span className="text-sky-400 font-mono font-bold">{percentile}%</span>
              </div>
              <input
                type="range"
                min="40.0"
                max="99.9"
                step="0.5"
                value={percentile}
                onChange={(e) => setPercentile(Number(e.target.value))}
                className="w-full accent-sky-500 cursor-pointer"
              />
            </div>

            {/* 10+2 Percentage & UG Degree */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-300">12th Marks (%)</label>
                <input
                  type="number"
                  min="40"
                  max="100"
                  value={twelfthPct}
                  onChange={(e) => setTwelfthPct(Number(e.target.value))}
                  className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-sky-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-300">UG CGPA (/10)</label>
                <input
                  type="number"
                  min="4"
                  max="10"
                  step="0.1"
                  value={ugCgpa}
                  onChange={(e) => setUgCgpa(Number(e.target.value))}
                  className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-sky-500"
                />
              </div>
            </div>

            {/* UG Degree Name (Crucial for MCA rule test) */}
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-slate-300">Undergraduate Degree (for PG)</label>
              <input
                type="text"
                value={ugDegree}
                onChange={(e) => setUgDegree(e.target.value)}
                placeholder="e.g. B.Sc Mathematics, BCA, B.Tech..."
                className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-sky-500"
              />
            </div>

            {/* Subjects Studied Toggle Chips */}
            <div className="space-y-1.5">
              <label className="text-[11px] font-semibold text-slate-300">Subjects Studied at 10+2 / UG</label>
              <div className="flex flex-wrap gap-1.5">
                {allAvailableSubjects.map((sub) => {
                  const active = subjects.includes(sub);
                  return (
                    <button
                      key={sub}
                      type="button"
                      onClick={() => toggleSubject(sub)}
                      className={`text-[11px] px-2.5 py-1 rounded-lg border transition-all ${
                        active
                          ? 'bg-sky-600/30 text-sky-300 border-sky-500/50 font-medium'
                          : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-slate-200'
                      }`}
                    >
                      {sub} {active && '✔'}
                    </button>
                  );
                })}
              </div>
            </div>

          </div>
        </div>

        {/* Right: Explainable AI Result Card */}
        <div className="lg:col-span-8">
          {loading ? (
            <div className="glass-card rounded-2xl p-12 border border-slate-800 flex flex-col items-center justify-center text-center space-y-3">
              <RefreshCw className="w-8 h-8 text-sky-400 animate-spin" />
              <p className="text-sm font-semibold text-slate-300">Evaluating statutory eligibility rules and computing feature attributions...</p>
            </div>
          ) : (
            <XAIExplanationCard decision={decision} />
          )}
        </div>

      </div>

    </div>
  );
}

