import React, { useState, useEffect } from 'react';
import { 
  LineChart, 
  TrendingUp, 
  Users, 
  Layers, 
  Download, 
  CheckCircle, 
  PieChart,
  BarChart3,
  FileSpreadsheet,
  Printer,
  ShieldCheck
} from 'lucide-react';
import { api } from '../services/api';

export default function OfficerAnalytics() {
  const [dashboardData, setDashboardData] = useState(null);
  const [cutoffTrends, setCutoffTrends] = useState(null);
  const [selectedProgram, setSelectedProgram] = useState('PROG-BTECH-CSE');
  const [applicantsSummary, setApplicantsSummary] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchDashboard();
    fetchApplicants();
  }, []);

  useEffect(() => {
    fetchCutoffs(selectedProgram);
  }, [selectedProgram]);

  const fetchDashboard = async () => {
    try {
      const data = await api.getAnalyticsDashboard();
      setDashboardData(data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchCutoffs = async (progId) => {
    try {
      const data = await api.getCutoffTrends(progId);
      setCutoffTrends(data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchApplicants = async () => {
    try {
      const data = await api.getApplicantsSummary();
      setApplicantsSummary(data);
    } catch (err) {
      console.error(err);
    }
  };

  const exportCSVReport = () => {
    if (!dashboardData) return;
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Program Name,College Name,Total Seats,Filled Seats,Vacant Seats,Annual Fee,Avg Placement LPA\n";
    
    dashboardData.program_seat_breakdown.forEach(row => {
      csvContent += `"${row.program_name}","${row.college_name}",${row.total_seats},${row.filled_seats},${row.vacant_seats},${row.annual_fee},${row.avg_ctc_lpa}\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "admission_analytics_report_2025.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <LineChart className="w-6 h-6 text-indigo-400" />
            Admission Analytics, Cutoff Trends & Decision Monitoring
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time analytics for admission officers: multi-year cutoff progression, statutory quota compliance, and seat utilization
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportCSVReport}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center gap-1.5 transition-all shadow-md shadow-indigo-600/20"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Export CSV Dataset</span>
          </button>
          <button
            onClick={() => window.print()}
            className="px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5"
          >
            <Printer className="w-4 h-4" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* Metric Cards Banner */}
      {dashboardData && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="glass-card rounded-2xl p-4 border border-slate-800">
            <div className="text-[11px] text-slate-400 font-semibold uppercase">Total Applications</div>
            <div className="text-2xl font-black text-white mt-1">
              {dashboardData.overview.total_applications_received.toLocaleString()}
            </div>
            <div className="text-[10px] text-emerald-400 mt-1 font-semibold">↑ +14.2% YoY Growth</div>
          </div>

          <div className="glass-card rounded-2xl p-4 border border-slate-800">
            <div className="text-[11px] text-slate-400 font-semibold uppercase">Overall Seat Utilization</div>
            <div className="text-2xl font-black text-sky-400 mt-1">
              {dashboardData.overview.overall_seat_utilization_pct}%
            </div>
            <div className="text-[10px] text-slate-400 mt-1">Across 8 Degree Streams</div>
          </div>

          <div className="glass-card rounded-2xl p-4 border border-slate-800">
            <div className="text-[11px] text-slate-400 font-semibold uppercase">Total Sanctioned Seats</div>
            <div className="text-2xl font-black text-purple-400 mt-1">
              {dashboardData.overview.total_seats}
            </div>
            <div className="text-[10px] text-slate-400 mt-1">AICTE / UGC Accredited</div>
          </div>

          <div className="glass-card rounded-2xl p-4 border border-slate-800">
            <div className="text-[11px] text-slate-400 font-semibold uppercase">Admission Acceptance Rate</div>
            <div className="text-2xl font-black text-amber-400 mt-1">
              {dashboardData.overview.acceptance_rate_pct}%
            </div>
            <div className="text-[10px] text-slate-400 mt-1">Highly Competitive Selectivity</div>
          </div>
        </div>
      )}

      {/* 5-Year Cutoff Trends Chart (2021-2025) */}
      <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-sky-400" />
              5-Year Historical Cutoff Trends (2021 – 2025)
            </h3>
            <p className="text-xs text-slate-400">
              Cutoff percentiles categorized by statutory reservation quotas
            </p>
          </div>

          <select
            value={selectedProgram}
            onChange={(e) => setSelectedProgram(e.target.value)}
            className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-sky-500"
          >
            <option value="PROG-BTECH-CSE">B.Tech - Computer Science & Eng.</option>
            <option value="PROG-BTECH-AIDS">B.Tech - AI & Data Science</option>
            <option value="PROG-BTECH-ECE">B.Tech - Electronics & Comm.</option>
            <option value="PROG-MCA">Master of Computer Applications (MCA)</option>
            <option value="PROG-MBA-TECH">MBA in Technology & Analytics</option>
            <option value="PROG-BTECH-MECH">B.Tech - Mechanical & Mechatronics</option>
          </select>
        </div>

        {/* Visual Trend Bars / Multi-Year Matrix */}
        {cutoffTrends && (
          <div className="space-y-4 pt-2">
            <div className="flex flex-wrap gap-4 text-xs font-semibold">
              {cutoffTrends.series?.map((s, idx) => (
                <div key={idx} className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: s.color }} />
                  <span className="text-slate-300">{s.label}</span>
                </div>
              ))}
            </div>

            {/* Custom Interactive Trend Visualization Table & Trend Indicators */}
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left border border-slate-800 rounded-xl overflow-hidden">
                <thead className="bg-slate-900/90 text-slate-300 font-bold uppercase tracking-wider text-[10px]">
                  <tr>
                    <th className="p-3">Category Quota</th>
                    {cutoffTrends.years?.map(yr => (
                      <th key={yr} className="p-3 text-center">Year {yr}</th>
                    ))}
                    <th className="p-3 text-right">5-Year Shift</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {cutoffTrends.series?.map((s, sIdx) => {
                    const first = s.data[0] || 0;
                    const last = s.data[s.data.length - 1] || 0;
                    const diff = (last - first).toFixed(1);
                    const isUp = Number(diff) >= 0;

                    return (
                      <tr key={sIdx} className="hover:bg-slate-900/50">
                        <td className="p-3 font-semibold text-white flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: s.color }} />
                          <span>{s.label}</span>
                        </td>
                        {s.data.map((val, vIdx) => (
                          <td key={vIdx} className="p-3 text-center font-mono">
                            <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-200">
                              {val}%
                            </span>
                          </td>
                        ))}
                        <td className={`p-3 text-right font-mono font-bold ${isUp ? 'text-emerald-400' : 'text-rose-400'}`}>
                          {isUp ? '↑ +' : '↓ '}{diff}%
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Two Column Layout: Seat Matrix Breakdown & Statutory Quota Distribution */}
      {dashboardData && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Seat Matrix Breakdown */}
          <div className="lg:col-span-7 glass-card rounded-2xl p-5 border border-slate-800 space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-sky-400" />
              Program Seat Matrix & Occupancy Status
            </h3>

            <div className="space-y-2.5 pt-1">
              {dashboardData.program_seat_breakdown.map((prog, idx) => {
                const pct = Math.round((prog.filled_seats / prog.total_seats) * 100);
                return (
                  <div key={idx} className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 space-y-1.5">
                    <div className="flex justify-between text-xs font-semibold">
                      <span className="text-white truncate">{prog.program_name}</span>
                      <span className="text-emerald-400 font-mono">{prog.filled_seats}/{prog.total_seats} Filled ({pct}%)</span>
                    </div>
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${pct}%` }} />
                    </div>
                    <div className="flex justify-between text-[11px] text-slate-400">
                      <span>{prog.college_name}</span>
                      <span>Vacant: <strong className="text-amber-400 font-mono">{prog.vacant_seats}</strong> seats</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Statutory Quota Allocation */}
          <div className="lg:col-span-5 glass-card rounded-2xl p-5 border border-slate-800 space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <PieChart className="w-4 h-4 text-purple-400" />
              Statutory Quota Allocation Rules
            </h3>

            <div className="space-y-3 pt-1">
              {dashboardData.category_distribution.map((cat, idx) => (
                <div key={idx} className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-bold text-white">{cat.category}</div>
                    <div className="text-[11px] text-slate-400">Statutory Quota: {cat.quota_percentage}%</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-black text-sky-400 font-mono">{cat.allocated_seats}</div>
                    <div className="text-[10px] text-slate-400">Seats Reserved</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

    </div>
  );
}

