import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  Search, 
  RefreshCw, 
  CheckCircle, 
  Award, 
  GraduationCap, 
  FileText, 
  Building2,
  DollarSign
} from 'lucide-react';
import { api } from '../services/api';

export default function KnowledgeRepository() {
  const [activeTab, setActiveTab] = useState('policies'); // 'policies', 'colleges', 'scholarships'
  const [searchQuery, setSearchQuery] = useState('');
  const [policies, setPolicies] = useState([]);
  const [colleges, setColleges] = useState([]);
  const [scholarships, setScholarships] = useState([]);
  const [reindexing, setReindexing] = useState(false);
  const [reindexMsg, setReindexMsg] = useState(null);

  useEffect(() => {
    loadAll();
  }, []);

  const loadAll = async () => {
    try {
      const [polData, colData, schData] = await Promise.all([
        api.getPolicies(),
        api.getColleges(),
        api.getScholarships()
      ]);
      setPolicies(polData);
      setColleges(colData);
      setScholarships(schData);
    } catch (err) {
      console.error(err);
    }
  };

  const handleReindex = async () => {
    setReindexing(true);
    setReindexMsg(null);
    try {
      const res = await api.triggerReindex();
      setReindexMsg(res.message);
      setTimeout(() => setReindexMsg(null), 4000);
    } catch (err) {
      setReindexMsg('Re-indexing failed.');
    } finally {
      setReindexing(false);
    }
  };

  const filterText = (str) => {
    if (!searchQuery.trim()) return true;
    return String(str || '').toLowerCase().includes(searchQuery.toLowerCase());
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-sky-400" />
            Institutional Knowledge Base & Policy Repository
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Centralized repository of statutory regulations, fee schedules, reservation matrices, and vector index chunks
          </p>
        </div>

        <button
          onClick={handleReindex}
          disabled={reindexing}
          className="px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white font-semibold text-xs flex items-center gap-2 transition-all shadow-md shadow-sky-600/20"
        >
          <RefreshCw className={`w-4 h-4 ${reindexing ? 'animate-spin' : ''}`} />
          <span>{reindexing ? 'Re-building Vectors...' : 'Re-index Knowledge Base'}</span>
        </button>
      </div>

      {reindexMsg && (
        <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>{reindexMsg}</span>
        </div>
      )}

      {/* Tabs & Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('policies')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              activeTab === 'policies'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Admission Regulations ({policies.length})
          </button>
          <button
            onClick={() => setActiveTab('colleges')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              activeTab === 'colleges'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Colleges & Programs ({colleges.length})
          </button>
          <button
            onClick={() => setActiveTab('scholarships')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              activeTab === 'scholarships'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Scholarships & Fee Waivers ({scholarships.length})
          </button>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search regulations..."
            className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-500"
          />
        </div>
      </div>

      {/* Tab Contents */}
      {activeTab === 'policies' && (
        <div className="space-y-4">
          {policies.filter(p => filterText(p.title + p.description)).map((pol) => (
            <div key={pol.id} className="glass-card rounded-2xl p-5 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-sky-500/10 text-sky-400 border border-sky-500/20 font-mono">
                  {pol.id}
                </span>
                <span className="text-xs text-slate-400 font-medium">Category: {pol.category}</span>
              </div>
              <h3 className="text-base font-bold text-white">{pol.title}</h3>
              <p className="text-xs text-slate-300 leading-relaxed">{pol.description}</p>
              
              {pol.rules?.relaxation_rules && (
                <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 space-y-1 text-xs">
                  <div className="font-bold text-slate-400 uppercase text-[10px]">Statutory Relaxations:</div>
                  {Object.entries(pol.rules.relaxation_rules).map(([k, v]) => (
                    <div key={k} className="text-slate-300">
                      <strong className="text-sky-400">{k}:</strong> {v}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {activeTab === 'colleges' && (
        <div className="space-y-6">
          {colleges.map((col) => (
            <div key={col.college_id} className="glass-card rounded-2xl p-6 border border-slate-800 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <Building2 className="w-5 h-5 text-sky-400" />
                    <h3 className="text-base font-bold text-white">{col.college_name}</h3>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">{col.location} • {col.type}</p>
                </div>
                <div className="text-right">
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-indigo-950 text-indigo-300 border border-indigo-800">
                    {col.accreditation}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {col.programs?.map((prog) => (
                  <div key={prog.program_id} className="bg-slate-900/90 p-4 rounded-xl border border-slate-800 space-y-2">
                    <h4 className="text-sm font-bold text-white">{prog.program_name}</h4>
                    <p className="text-xs text-slate-400">{prog.eligibility_summary}</p>
                    <div className="pt-2 border-t border-slate-800 flex justify-between text-xs font-mono">
                      <span className="text-sky-300">Seats: {prog.total_seats}</span>
                      <span className="text-emerald-400">INR {prog.annual_tuition_fee.toLocaleString()}/yr</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'scholarships' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {scholarships.filter(s => filterText(s.name + s.description)).map((sch) => (
            <div key={sch.scholarship_id} className="glass-card rounded-2xl p-5 border border-slate-800 space-y-3 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    {sch.target_category}
                  </span>
                  <span className="text-xs text-slate-400">{sch.provider}</span>
                </div>

                <h3 className="text-sm font-bold text-white leading-snug">{sch.name}</h3>
                <div className="my-2 p-2.5 rounded-xl bg-emerald-950/20 border border-emerald-500/20 text-xs font-bold text-emerald-300">
                  {sch.benefit}
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">{sch.description}</p>
              </div>

              <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-400 space-y-1">
                <div className="font-semibold text-slate-300">Required Documents:</div>
                <div className="text-slate-400">{sch.required_documents?.join(', ')}</div>
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  );
}

