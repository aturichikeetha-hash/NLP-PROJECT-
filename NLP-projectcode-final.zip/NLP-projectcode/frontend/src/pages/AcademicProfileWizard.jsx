import React, { useState, useEffect } from 'react';
import { 
  User, 
  Save, 
  Award, 
  BookOpen, 
  CheckCircle, 
  Plus, 
  X, 
  Sparkles,
  Layers,
  GraduationCap
} from 'lucide-react';
import { api } from '../services/api';

export default function AcademicProfileWizard({ currentUser, onProfileUpdated }) {
  const [profile, setProfile] = useState({
    tenth_percentage: 88.0,
    twelfth_percentage: 85.5,
    ug_cgpa: 8.2,
    ug_degree: 'B.Sc Mathematics',
    subjects_studied: ['Mathematics', 'Physics', 'Chemistry', 'Computer Science'],
    entrance_exam_name: 'JEE Main',
    entrance_score: 145.0,
    entrance_percentile: 93.8,
    entrance_rank: 18400,
    reservation_category: 'General',
    is_pwd: false,
    state_domicile: 'Home State',
    annual_family_income: 550000.0,
    career_interests: ['Artificial Intelligence', 'Data Science', 'Cloud Architecture'],
    skills: ['Python', 'Algorithms', 'Mathematics', 'Machine Learning'],
    preferred_degrees: ['B.Tech', 'MCA', 'MBA']
  });

  const [saving, setSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [newSkill, setNewSkill] = useState('');
  const [newInterest, setNewInterest] = useState('');

  useEffect(() => {
    if (currentUser?.id) {
      loadProfile(currentUser.id);
    }
  }, [currentUser]);

  const loadProfile = async (userId) => {
    try {
      const data = await api.getProfile(userId);
      if (data) setProfile(data);
    } catch (err) {
      console.error('Error loading profile:', err);
    }
  };

  const handleChange = (field, value) => {
    setProfile(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const updated = await api.updateProfile(currentUser?.id || 1, profile);
      setProfile(updated);
      setSaveSuccess(true);
      if (onProfileUpdated) onProfileUpdated(updated);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      console.error('Error saving profile:', err);
    } finally {
      setSaving(false);
    }
  };

  const addSkill = () => {
    if (newSkill.trim() && !profile.skills.includes(newSkill.trim())) {
      setProfile(prev => ({
        ...prev,
        skills: [...prev.skills, newSkill.trim()]
      }));
      setNewSkill('');
    }
  };

  const removeSkill = (skillToRemove) => {
    setProfile(prev => ({
      ...prev,
      skills: prev.skills.filter(s => s !== skillToRemove)
    }));
  };

  const addInterest = () => {
    if (newInterest.trim() && !profile.career_interests.includes(newInterest.trim())) {
      setProfile(prev => ({
        ...prev,
        career_interests: [...prev.career_interests, newInterest.trim()]
      }));
      setNewInterest('');
    }
  };

  const removeInterest = (itemToRemove) => {
    setProfile(prev => ({
      ...prev,
      career_interests: prev.career_interests.filter(i => i !== itemToRemove)
    }));
  };

  return (
    <form onSubmit={handleSave} className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <User className="w-6 h-6 text-sky-400" />
            Applicant Academic Profile Management
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Maintain your academic credentials, entrance percentiles, and category quota parameters
          </p>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="px-6 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs flex items-center gap-2 transition-all shadow-lg shadow-sky-600/20"
        >
          {saving ? <Sparkles className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          <span>{saving ? 'Saving Profile...' : 'Save & Synchronize'}</span>
        </button>
      </div>

      {saveSuccess && (
        <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>Academic Profile successfully synchronized with AI Decision Support Engines!</span>
        </div>
      )}

      {/* Grid of Profile Sections */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        
        {/* Section 1: Academic Scores */}
        <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800 text-sm font-bold text-white">
            <GraduationCap className="w-4 h-4 text-sky-400" />
            <span>1. Academic Records</span>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-xs font-semibold text-slate-300">10th Standard Percentage (%)</label>
              <input
                type="number"
                step="0.1"
                min="0"
                max="100"
                value={profile.tenth_percentage}
                onChange={(e) => handleChange('tenth_percentage', parseFloat(e.target.value))}
                className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-sky-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300">12th Standard / Intermediate (%)</label>
              <input
                type="number"
                step="0.1"
                min="0"
                max="100"
                value={profile.twelfth_percentage}
                onChange={(e) => handleChange('twelfth_percentage', parseFloat(e.target.value))}
                className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-sky-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300">Undergraduate Degree (for PG)</label>
              <input
                type="text"
                value={profile.ug_degree}
                onChange={(e) => handleChange('ug_degree', e.target.value)}
                placeholder="e.g. B.Sc Mathematics, BCA, B.Tech"
                className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-sky-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300">Undergraduate CGPA (out of 10.0)</label>
              <input
                type="number"
                step="0.1"
                min="0"
                max="10"
                value={profile.ug_cgpa}
                onChange={(e) => handleChange('ug_cgpa', parseFloat(e.target.value))}
                className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-sky-500"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Entrance Examinations */}
        <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800 text-sm font-bold text-white">
            <Award className="w-4 h-4 text-sky-400" />
            <span>2. Entrance Exam Scores</span>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-xs font-semibold text-slate-300">Primary Entrance Exam</label>
              <select
                value={profile.entrance_exam_name}
                onChange={(e) => handleChange('entrance_exam_name', e.target.value)}
                className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-sky-500"
              >
                <option value="JEE Main">JEE Main (B.Tech)</option>
                <option value="State CET">State CET (Engineering / Tech)</option>
                <option value="NIMCET">NIMCET / State MCA CET (MCA)</option>
                <option value="CAT">CAT / MAT / CMAT (MBA)</option>
                <option value="GATE">GATE (M.Tech)</option>
                <option value="CUET-UG">CUET-UG (B.Sc / General)</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300">Entrance Score / Marks</label>
              <input
                type="number"
                value={profile.entrance_score}
                onChange={(e) => handleChange('entrance_score', parseFloat(e.target.value))}
                className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-sky-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300">Percentile (%)</label>
              <input
                type="number"
                step="0.01"
                min="0"
                max="100"
                value={profile.entrance_percentile}
                onChange={(e) => handleChange('entrance_percentile', parseFloat(e.target.value))}
                className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-sky-500 font-mono font-bold text-sky-400"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300">All India / State Rank</label>
              <input
                type="number"
                value={profile.entrance_rank}
                onChange={(e) => handleChange('entrance_rank', parseInt(e.target.value) || 0)}
                className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-sky-500 font-mono"
              />
            </div>
          </div>
        </div>

        {/* Section 3: Quota, Category & Financials */}
        <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800 text-sm font-bold text-white">
            <BookOpen className="w-4 h-4 text-sky-400" />
            <span>3. Reservation & Quotas</span>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-xs font-semibold text-slate-300">Statutory Category Quota</label>
              <select
                value={profile.reservation_category}
                onChange={(e) => handleChange('reservation_category', e.target.value)}
                className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-sky-500"
              >
                <option value="General">General / Open (UR)</option>
                <option value="OBC-NCL">OBC-NCL (27% Central Quota)</option>
                <option value="EWS">EWS (10% Income Quota)</option>
                <option value="SC">Scheduled Castes (SC - 15%)</option>
                <option value="ST">Scheduled Tribes (ST - 7.5%)</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300">Annual Family Income (INR)</label>
              <input
                type="number"
                value={profile.annual_family_income}
                onChange={(e) => handleChange('annual_family_income', parseFloat(e.target.value))}
                className="w-full mt-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-sky-500"
              />
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                &lt; 8 Lakhs qualifies for EWS/TFW fee concessions
              </span>
            </div>

            <div className="pt-2">
              <label className="flex items-center gap-2 text-xs font-medium text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={profile.is_pwd}
                  onChange={(e) => handleChange('is_pwd', e.target.checked)}
                  className="rounded bg-slate-900 border-slate-700 text-sky-600 focus:ring-sky-500"
                />
                <span>Person with Disability (PwD - 5% Horizontal Quota)</span>
              </label>
            </div>
          </div>
        </div>

      </div>

      {/* Section 4: Skills & Career Interests */}
      <div className="glass-card rounded-2xl p-5 border border-slate-800 space-y-4">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-800 text-sm font-bold text-white">
          <Sparkles className="w-4 h-4 text-sky-400" />
          <span>4. Skills & Career Preferences (Used for Semantic Recommender)</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Skills */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300">Technical Skills & Strengths</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                placeholder="Add skill (e.g. Python, SQL, C++, Statistics)..."
                className="flex-1 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-sky-500"
              />
              <button
                type="button"
                onClick={addSkill}
                className="px-3 py-1.5 bg-slate-800 hover:bg-sky-600 text-white rounded-lg text-xs font-semibold flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> Add
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {profile.skills?.map((skill, idx) => (
                <span key={idx} className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-950/80 text-sky-300 border border-sky-800/60 text-xs">
                  {skill}
                  <button type="button" onClick={() => removeSkill(skill)}>
                    <X className="w-3 h-3 hover:text-white" />
                  </button>
                </span>
              ))}
            </div>
          </div>

          {/* Career Interests */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-300">Target Career Interests</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={newInterest}
                onChange={(e) => setNewInterest(e.target.value)}
                placeholder="Add interest (e.g. Machine Learning, Cloud Systems, Product Management)..."
                className="flex-1 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-sky-500"
              />
              <button
                type="button"
                onClick={addInterest}
                className="px-3 py-1.5 bg-slate-800 hover:bg-sky-600 text-white rounded-lg text-xs font-semibold flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" /> Add
              </button>
            </div>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {profile.career_interests?.map((interest, idx) => (
                <span key={idx} className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-950/80 text-indigo-300 border border-indigo-800/60 text-xs">
                  {interest}
                  <button type="button" onClick={() => removeInterest(interest)}>
                    <X className="w-3 h-3 hover:text-white" />
                  </button>
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

    </form>
  );
}

