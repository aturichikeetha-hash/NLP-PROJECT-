import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Search, 
  CheckCircle2, 
  Clock, 
  FileText, 
  ShieldCheck, 
  AlertCircle,
  Eye
} from 'lucide-react';
import { api } from '../services/api';

export default function ApplicantsReview({ onInspectApplicant }) {
  const [applicants, setApplicants] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchApplicants();
  }, []);

  const fetchApplicants = async () => {
    setLoading(true);
    try {
      const data = await api.getApplicantsSummary();
      setApplicants(data?.applicants || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const filtered = applicants.filter(a => 
    a.name.toLowerCase().includes(search.toLowerCase()) || 
    a.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Users className="w-6 h-6 text-indigo-400" />
            Applicant Management & Document Audit Console
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Review registered candidates, inspect verified document packages, and audit eligibility decisions
          </p>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search candidate name..."
            className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
          />
        </div>
      </div>

      {/* Applicants Table */}
      <div className="glass-card rounded-2xl border border-slate-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-900/90 text-slate-300 font-bold uppercase tracking-wider text-[10px] border-b border-slate-800">
              <tr>
                <th className="p-4">Applicant Profile</th>
                <th className="p-4">Registration ID</th>
                <th className="p-4">Documents Uploaded</th>
                <th className="p-4">Verification Audit</th>
                <th className="p-4">Submission Date</th>
                <th className="p-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filtered.map((app) => (
                <tr key={app.user_id} className="hover:bg-slate-900/50 transition-colors">
                  <td className="p-4">
                    <div className="font-bold text-white text-sm">{app.name}</div>
                    <div className="text-slate-400 text-xs">{app.email}</div>
                  </td>
                  <td className="p-4 font-mono text-slate-300">
                    APP-2025-{String(app.user_id).padStart(4, '0')}
                  </td>
                  <td className="p-4 font-mono font-semibold text-sky-400">
                    {app.documents_uploaded} Files
                  </td>
                  <td className="p-4">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold ${
                      app.verification_status === 'VERIFIED'
                        ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                        : 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                    }`}>
                      {app.verification_status === 'VERIFIED' ? (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      ) : (
                        <Clock className="w-3.5 h-3.5" />
                      )}
                      {app.verification_status}
                    </span>
                  </td>
                  <td className="p-4 text-slate-400">
                    {app.registered_at || '2026-08-28'}
                  </td>
                  <td className="p-4 text-right">
                    <button
                      onClick={() => onInspectApplicant && onInspectApplicant(app.user_id)}
                      className="px-3 py-1.5 rounded-lg bg-indigo-600/30 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/40 text-xs font-semibold flex items-center gap-1.5 ml-auto transition-all"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Audit Profile</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}

