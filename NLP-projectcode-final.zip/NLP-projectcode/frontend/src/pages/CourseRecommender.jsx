import React, { useState, useEffect } from 'react';
import { 
  Compass, 
  Sparkles, 
  Award, 
  TrendingUp, 
  Briefcase, 
  DollarSign, 
  GraduationCap, 
  CheckCircle2, 
  Star,
  Layers,
  ArrowUpRight
} from 'lucide-react';
import { api } from '../services/api';

export default function CourseRecommender({ currentUser, userProfile, onSelectProgramForXAI }) {
  const [recommendations, setRecommendations] = useState(null);
  const [activeTier, setActiveTier] = useState('all'); // 'all', 'Dream', 'Target', 'Safe'
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchRecommendations();
  }, [userProfile]);

  const fetchRecommendations = async () => {
    setLoading(true);
    try {
      const res = await api.getRecommendations({
        user_id: currentUser?.id,
        category: userProfile?.reservation_category,
        percentile: userProfile?.entrance_percentile
      });
      setRecommendations(res);
    } catch (err) {
      console.error('Error fetching recommendations:', err);
    } finally {
      setLoading(false);
    }
  };

  const getFilteredItems = () => {
    if (!recommendations) return [];
    const all = [
      ...(recommendations.target_options || []),
      ...(recommendations.safe_options || []),
      ...(recommendations.dream_options || [])
    ];
    if (activeTier === 'all') return all;
    if (activeTier === 'Dream') return recommendations.dream_options || [];
    if (activeTier === 'Target') return recommendations.target_options || [];
    if (activeTier === 'Safe') return recommendations.safe_options || [];
    return all;
  };

  const filteredItems = getFilteredItems();

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Compass className="w-6 h-6 text-sky-400" />
            Personalized Course & College Recommendation Engine
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Multi-factor cosine matching analyzing academic profile, entrance scores, quota thresholds, and career interests
          </p>
        </div>

        {/* Category Profile Tag */}
        {recommendations && (
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs">
            <span className="text-slate-400">Quota Context:</span>
            <span className="font-bold text-sky-400">{recommendations.user_category}</span>
            <span className="text-slate-500">•</span>
            <span className="text-slate-400">Percentile:</span>
            <span className="font-bold text-emerald-400">{recommendations.user_entrance_percentile}%</span>
          </div>
        )}
      </div>

      {/* Tier Filter Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveTier('all')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
            activeTier === 'all'
              ? 'bg-sky-600 text-white shadow-md shadow-sky-600/20'
              : 'bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          All Recommendations ({recommendations?.total_matches || 0})
        </button>

        <button
          onClick={() => setActiveTier('Target')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
            activeTier === 'Target'
              ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
              : 'bg-slate-900/80 text-emerald-400 hover:text-emerald-300 border border-emerald-900/30'
          }`}
        >
          <span>Target Matches ({recommendations?.target_options?.length || 0})</span>
          <span className="text-[10px] bg-emerald-950 px-1.5 py-0.5 rounded text-emerald-300">Optimal</span>
        </button>

        <button
          onClick={() => setActiveTier('Dream')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
            activeTier === 'Dream'
              ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
              : 'bg-slate-900/80 text-purple-400 hover:text-purple-300 border border-purple-900/30'
          }`}
        >
          <Star className="w-3.5 h-3.5" />
          <span>Dream Colleges ({recommendations?.dream_options?.length || 0})</span>
        </button>

        <button
          onClick={() => setActiveTier('Safe')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
            activeTier === 'Safe'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
              : 'bg-slate-900/80 text-blue-400 hover:text-blue-300 border border-blue-900/30'
          }`}
        >
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>Safe / Assured Options ({recommendations?.safe_options?.length || 0})</span>
        </button>
      </div>

      {/* Recommendations Grid */}
      {loading ? (
        <div className="glass-card rounded-2xl p-12 border border-slate-800 text-center text-slate-400 text-sm">
          Computing multi-criteria recommendations across university databases...
        </div>
      ) : filteredItems.length === 0 ? (
        <div className="glass-card rounded-2xl p-12 border border-slate-800 text-center text-slate-400 text-sm">
          No recommendations found for this filter. Try adjusting your profile scores.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item, idx) => {
            const tierColor = item.tier === 'Dream' 
              ? 'from-purple-500/20 to-purple-900/10 border-purple-500/30 text-purple-400'
              : item.tier === 'Target'
              ? 'from-emerald-500/20 to-emerald-900/10 border-emerald-500/30 text-emerald-400'
              : 'from-blue-500/20 to-blue-900/10 border-blue-500/30 text-blue-400';

            return (
              <div 
                key={idx}
                className="glass-card glass-card-hover rounded-2xl p-5 border border-slate-800 flex flex-col justify-between space-y-4"
              >
                <div>
                  {/* Top Bar */}
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className={`text-[11px] font-extrabold uppercase tracking-wider px-2.5 py-1 rounded-lg border ${tierColor}`}>
                      {item.tier} Option
                    </span>
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 block">Overall Match</span>
                      <span className="text-base font-black text-sky-400 font-mono">
                        {item.overall_match_score}%
                      </span>
                    </div>
                  </div>

                  {/* Program & College Name */}
                  <h3 className="text-base font-bold text-white leading-snug">
                    {item.program_name}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1 font-medium">
                    {item.college_name}
                  </p>

                  {/* Key Metrics Grid */}
                  <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-slate-800/80 text-xs">
                    <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Admission Chance</span>
                      <span className="font-bold text-emerald-400">{item.admission_probability}% Probable</span>
                    </div>
                    <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Avg. Placement</span>
                      <span className="font-bold text-sky-300">INR {item.average_placement_lpa} LPA</span>
                    </div>
                    <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Annual Tuition</span>
                      <span className="font-bold text-slate-200">INR {item.annual_tuition_fee.toLocaleString()}</span>
                    </div>
                    <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Placement Rate</span>
                      <span className="font-bold text-indigo-400">{item.placement_rate_pct}% Placed</span>
                    </div>
                  </div>

                  {/* Fit Progress Bars */}
                  <div className="space-y-1.5 mt-4 text-[11px]">
                    <div className="flex justify-between text-slate-400">
                      <span>Interests Alignment</span>
                      <span className="text-sky-400 font-semibold">{item.interests_alignment_score}%</span>
                    </div>
                    <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                      <div className="h-full bg-sky-500 rounded-full" style={{ width: `${item.interests_alignment_score}%` }} />
                    </div>
                  </div>

                  {/* Reasons Highlights */}
                  <div className="mt-4 space-y-1">
                    <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                      Recommendation Drivers:
                    </div>
                    <ul className="space-y-1">
                      {item.reasons_for_recommendation?.slice(0, 2).map((r, rIdx) => (
                        <li key={rIdx} className="text-xs text-slate-300 flex items-start gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                          <span className="line-clamp-2">{r}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Bottom Action */}
                <button
                  onClick={() => onSelectProgramForXAI && onSelectProgramForXAI(item.program_id)}
                  className="w-full mt-2 py-2 px-3 rounded-xl bg-slate-800 hover:bg-sky-600 text-slate-200 hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-all"
                >
                  <span>Evaluate XAI Eligibility</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      )}

    </div>
  );
}

