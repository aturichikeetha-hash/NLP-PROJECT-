import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Bot, 
  User, 
  Sparkles, 
  BookOpen, 
  ArrowRight, 
  ShieldCheck, 
  ExternalLink, 
  ChevronDown, 
  ChevronUp
} from 'lucide-react';
import { api } from '../services/api';

export default function AIChatAdvisor({ currentUser }) {
  const [messages, setMessages] = useState([
    {
      id: 'msg-1',
      sender: 'bot',
      text: "Hello! I am your **Smart Admission Advisor** powered by **Retrieval-Augmented Generation (RAG)** and institutional policy embeddings. \n\nAsk me any questions about course eligibility, entrance cutoffs, reservation relaxations, fee structures, or career prospects!",
      citations: [],
      model: "RAG Knowledge Synthesizer",
      followups: [
        "Can I apply for MCA with a B.Sc. Mathematics degree?",
        "What scholarships are available for economically weaker students?",
        "What were the 2025 JEE Main closing cutoffs for B.Tech CSE?"
      ]
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [expandedCitations, setExpandedCitations] = useState({});
  const chatEndRef = useRef(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handleSend = async (queryText = null) => {
    const textToSend = queryText || input;
    if (!textToSend.trim() || loading) return;

    const userMsg = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      citations: [],
      model: null
    };

    setMessages(prev => [...prev, userMsg]);
    if (!queryText) setInput('');
    setLoading(true);

    try {
      const res = await api.queryRAG(textToSend, 'local', currentUser?.id);
      const botMsg = {
        id: `bot-${Date.now()}`,
        sender: 'bot',
        text: res.answer,
        citations: res.citations || [],
        model: res.model_name,
        confidence: res.confidence,
        followups: res.suggested_followups || []
      };
      setMessages(prev => [...prev, botMsg]);
    } catch (err) {
      setMessages(prev => [
        ...prev,
        {
          id: `bot-err-${Date.now()}`,
          sender: 'bot',
          text: "I encountered an error retrieving institutional policies. Please check backend connection.",
          citations: [],
          model: "Error"
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const toggleCitation = (msgId) => {
    setExpandedCitations(prev => ({
      ...prev,
      [msgId]: !prev[msgId]
    }));
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] glass-card rounded-2xl border border-slate-800 overflow-hidden">
      {/* Message Stream */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {messages.map((msg) => {
          const isBot = msg.sender === 'bot';
          return (
            <div 
              key={msg.id}
              className={`flex items-start gap-3.5 ${isBot ? 'justify-start' : 'justify-end'}`}
            >
              {isBot && (
                <div className="w-8 h-8 rounded-xl bg-sky-600/30 border border-sky-500/40 text-sky-300 flex items-center justify-center shrink-0 mt-1">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div className={`max-w-2xl space-y-3 ${isBot ? 'w-full' : ''}`}>
                <div 
                  className={`p-4 rounded-2xl text-sm leading-relaxed ${
                    isBot 
                      ? 'bg-slate-900/90 border border-slate-800 text-slate-200' 
                      : 'bg-sky-600 text-white rounded-tr-none ml-auto'
                  }`}
                >
                  <div className="prose prose-invert max-w-none text-xs sm:text-sm whitespace-pre-line">
                    {msg.text}
                  </div>

                  {/* Model & Confidence footer for bot */}
                  {isBot && msg.model && (
                    <div className="mt-3 pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
                      <span className="flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5 text-sky-400" />
                        {msg.model}
                      </span>
                      {msg.confidence && (
                        <span className="text-emerald-400 font-medium">
                          Confidence: {msg.confidence}%
                        </span>
                      )}
                    </div>
                  )}
                </div>

                {/* Citations Drawer */}
                {isBot && msg.citations && msg.citations.length > 0 && (
                  <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3 text-xs space-y-2">
                    <button 
                      onClick={() => toggleCitation(msg.id)}
                      className="w-full flex items-center justify-between font-semibold text-sky-400 hover:text-sky-300 transition-colors"
                    >
                      <div className="flex items-center gap-1.5">
                        <BookOpen className="w-3.5 h-3.5" />
                        <span>Retrieved Policy Documents & Citations ({msg.citations.length})</span>
                      </div>
                      {expandedCitations[msg.id] ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>

                    {expandedCitations[msg.id] && (
                      <div className="space-y-2 pt-2 border-t border-slate-800">
                        {msg.citations.map((cite, idx) => (
                          <div key={idx} className="p-2 rounded-lg bg-slate-900/80 border border-slate-800/60 space-y-1">
                            <div className="flex items-center justify-between">
                              <span className="font-semibold text-slate-200">{cite.doc_title}</span>
                              <span className="text-[10px] px-1.5 py-0.5 rounded bg-sky-950 text-sky-300 border border-sky-800">
                                Score: {(cite.relevance_score * 100).toFixed(0)}%
                              </span>
                            </div>
                            <p className="text-slate-400 text-[11px] italic">"{cite.snippet}"</p>
                            <div className="text-[10px] text-slate-500 font-mono">
                              Doc Ref: {cite.doc_id} • Section: {cite.section}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* Suggested Followups */}
                {isBot && msg.followups && msg.followups.length > 0 && (
                  <div className="space-y-1.5 pt-1">
                    <div className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-sky-400" />
                      Suggested Follow-up Inquiries:
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {msg.followups.map((q, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleSend(q)}
                          className="text-xs px-3 py-1.5 rounded-full bg-slate-900 hover:bg-sky-950/60 text-slate-300 hover:text-sky-300 border border-slate-800 hover:border-sky-500/40 transition-all text-left flex items-center gap-1.5"
                        >
                          <span>{q}</span>
                          <ArrowRight className="w-3 h-3 shrink-0" />
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {!isBot && (
                <div className="w-8 h-8 rounded-xl bg-sky-600 text-white flex items-center justify-center shrink-0 mt-1">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          );
        })}

        {loading && (
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-sky-600/30 text-sky-300 flex items-center justify-center border border-sky-500/40">
              <Bot className="w-4 h-4 animate-spin" />
            </div>
            <div className="bg-slate-900 border border-slate-800 px-4 py-3 rounded-2xl text-xs text-slate-400 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-sky-400 animate-ping" />
              <span>Retrieving knowledge embeddings & generating grounded response...</span>
            </div>
          </div>
        )}

        <div ref={chatEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 border-t border-slate-800 bg-slate-900/90">
        <form 
          onSubmit={(e) => { e.preventDefault(); handleSend(); }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask anything (e.g. 'Can I apply for MCA with B.Sc Mathematics?' or 'What are the cutoff percentiles for OBC?')..."
            className="flex-1 px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
          />
          <button
            type="submit"
            disabled={!input.trim() || loading}
            className="px-5 py-3 rounded-xl bg-sky-600 hover:bg-sky-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold text-sm flex items-center gap-2 transition-all shadow-lg shadow-sky-600/20"
          >
            <span>Ask AI</span>
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>

    </div>
  );
}

