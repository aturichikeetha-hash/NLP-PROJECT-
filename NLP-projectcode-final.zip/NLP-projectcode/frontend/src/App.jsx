import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import AIChatAdvisor from './pages/AIChatAdvisor';
import EligibilityChecker from './pages/EligibilityChecker';
import CourseRecommender from './pages/CourseRecommender';
import AcademicProfileWizard from './pages/AcademicProfileWizard';
import DocumentVerification from './pages/DocumentVerification';
import CareerGuidance from './pages/CareerGuidance';
import OfficerAnalytics from './pages/OfficerAnalytics';
import ApplicantsReview from './pages/ApplicantsReview';
import KnowledgeRepository from './pages/KnowledgeRepository';
import { api } from './services/api';

export default function App() {
  const [activeRole, setActiveRole] = useState('applicant'); // 'applicant' | 'officer'
  const [activeTab, setActiveTab] = useState('rag-chat');
  const [currentUser, setCurrentUser] = useState(null);
  const [userProfile, setUserProfile] = useState(null);
  const [selectedXAIProgramId, setSelectedXAIProgramId] = useState('PROG-BTECH-CSE');

  useEffect(() => {
    initApp();
  }, []);

  useEffect(() => {
    // Switch default tab when role changes
    if (activeRole === 'officer' && (activeTab === 'profile' || activeTab === 'documents')) {
      setActiveTab('analytics');
    }
  }, [activeRole]);

  const initApp = async () => {
    try {
      const demoUsers = await api.getDemoUsers();
      const applicantUser = demoUsers.applicant;
      setCurrentUser(applicantUser);
      
      const profile = await api.getProfile(applicantUser.id);
      setUserProfile(profile);
    } catch (err) {
      console.error('Initialization error:', err);
      // Fallback local state if backend is booting
      setCurrentUser({ id: 1, name: 'Rahul Sharma', email: 'applicant@example.com', role: 'applicant' });
      setUserProfile({
        tenth_percentage: 88.0,
        twelfth_percentage: 85.5,
        ug_cgpa: 8.2,
        ug_degree: 'B.Sc Mathematics',
        subjects_studied: ['Mathematics', 'Physics', 'Chemistry', 'Computer Science'],
        entrance_exam_name: 'JEE Main',
        entrance_percentile: 93.8,
        entrance_rank: 18400,
        reservation_category: 'General',
        career_interests: ['Artificial Intelligence', 'Data Science'],
        skills: ['Python', 'Algorithms']
      });
    }
  };

  const handleSelectProgramForXAI = (programId) => {
    setSelectedXAIProgramId(programId);
    setActiveTab('eligibility');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-['Plus_Jakarta_Sans',sans-serif]">
      
      {/* Top Navigation Bar */}
      <Navbar 
        activeRole={activeRole} 
        setActiveRole={setActiveRole} 
        currentUser={currentUser} 
      />

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 w-full flex flex-col md:flex-row gap-6">
        
        {/* Left Navigation Sidebar */}
        <Sidebar 
          activeTab={activeTab} 
          setActiveTab={setActiveTab} 
          activeRole={activeRole} 
        />

        {/* Dynamic Main Workspace Tab */}
        <section className="flex-1 min-w-0">
          {activeTab === 'rag-chat' && (
            <AIChatAdvisor currentUser={currentUser} />
          )}

          {activeTab === 'eligibility' && (
            <EligibilityChecker 
              userProfile={userProfile} 
            />
          )}

          {activeTab === 'recommender' && (
            <CourseRecommender 
              currentUser={currentUser} 
              userProfile={userProfile}
              onSelectProgramForXAI={handleSelectProgramForXAI}
            />
          )}

          {activeTab === 'profile' && (
            <AcademicProfileWizard 
              currentUser={currentUser} 
              onProfileUpdated={(updated) => setUserProfile(updated)}
            />
          )}

          {activeTab === 'documents' && (
            <DocumentVerification 
              currentUser={currentUser} 
              userProfile={userProfile}
            />
          )}

          {activeTab === 'career' && (
            <CareerGuidance />
          )}

          {activeTab === 'analytics' && (
            <OfficerAnalytics />
          )}

          {activeTab === 'applicants-review' && (
            <ApplicantsReview 
              onInspectApplicant={(id) => {
                setActiveTab('eligibility');
              }}
            />
          )}

          {activeTab === 'knowledge-repo' && (
            <KnowledgeRepository />
          )}
        </section>

      </main>

      {/* Modern Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 text-center text-xs text-slate-500">
        <p>
          Smart College Admission Decision Support System • Built with Large Language Models (LLMs), RAG & Explainable AI (XAI)
        </p>
      </footer>

    </div>
  );
}

