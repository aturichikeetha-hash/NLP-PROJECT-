import React from 'react';
import { 
  CheckCircle2, 
  XCircle, 
  HelpCircle, 
  TrendingUp, 
  ShieldCheck, 
  Award, 
  Sparkles, 
  ArrowRight,
  Info
} from 'lucide-react';
import EligibilityBadge from './EligibilityBadge';

export default function XAIExplanationCard({ decision }) {
  if (!decision) return null;

  const confidence = decision.confidence_score || 0;
  const isHighConfidence = confidence >= 80;
  const isMedConfidence = confidence >= 60 && confidence < 80;

  return (
    <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-slate-800/80">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider text-sky-400">
              Explainable AI (XAI) Audit
            </span>
            <span className="text-xs px-2 py-0.5 rounded bg-sky-500/10 text-sky-300 border border-sky-500/20">
              Rule + Attribution Model
            </span>
          </div>
          <h3 className="text-xl font-bold text-white">
            {decision.program_name}
          </h3>
          <p className="text-sm text-slate-400">
            {decision.college_name} • Degree: <span className="text-slate-200 font-medium">{decision.degree}</span>
          </p>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-right">
            <div className="text-xs text-slate-400">XAI Confidence</div>
            <div className="text-2xl font-black tracking-tight text-white flex items-center justify-end gap-1">
              <span className={isHighConfidence ? 'text-emerald-400' : isMedConfidence ? 'text-amber-400' : 'text-rose-400'}>
                {confidence}%
              </span>
            </div>
          </div>
          <EligibilityBadge status={decision.status} size="lg" />
        </div>
      </div>

      {/* Summary Reason Callout */}
      <div className="bg-slate-900/90 rounded-xl p-4 border border-slate-800 flex items-start gap-3">
        <Sparkles className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
        <p className="text-sm text-slate-200 leading-relaxed font-medium">
          {decision.summary_reason}
        </p>
      </div>

      {/* Grid: Rule Checklist & Feature Attributions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left: Step-by-Step Rule Audit Checklist */}
        <div className="lg:col-span-7 space-y-3">
          <h4 className="text-sm font-semibold text-slate-300 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-sky-400" />
            Statutory Rule Verification Checklist
          </h4>
          
          <div className="space-y-2.5">
            {decision.rule_checklist?.map((rule, idx) => (
              <div 
                key={idx}
                className={`p-3.5 rounded-xl border transition-all ${
                  rule.is_satisfied 
                    ? 'bg-emerald-950/20 border-emerald-500/20' 
                    : 'bg-rose-950/20 border-rose-500/20'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-2.5">
                    {rule.is_satisfied ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                    )}
                    <div>
                      <div className="text-sm font-semibold text-white flex items-center gap-2">
                        {rule.rule_name}
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                          Weight: {rule.weight}x
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 mt-0.5">{rule.criterion}</p>
                      <div className="text-xs text-slate-400 mt-1">
                        Candidate Data: <span className="text-sky-300 font-mono">{rule.student_value}</span>
                      </div>
                    </div>
                  </div>
                  
                  <span className={`text-[11px] font-bold px-2 py-0.5 rounded uppercase tracking-wider shrink-0 ${
                    rule.is_satisfied ? 'text-emerald-400 bg-emerald-500/10' : 'text-rose-400 bg-rose-500/10'
                  }`}>
                    {rule.is_satisfied ? 'PASSED' : 'UNMET'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: SHAP / Feature Attributions & Counterfactuals */}
        <div className="lg:col-span-5 space-y-4">
          <div>
            <h4 className="text-sm font-semibold text-slate-300 flex items-center gap-2 mb-3">
              <TrendingUp className="w-4 h-4 text-sky-400" />
              Decision Feature Attributions
            </h4>
            
            <div className="space-y-3 bg-slate-900/60 p-3.5 rounded-xl border border-slate-800">
              {decision.feature_importances?.map((feat, idx) => {
                const isPos = feat.contribution_score >= 0;
                const absPct = Math.min(100, Math.round(Math.abs(feat.contribution_score) * 100));
                
                return (
                  <div key={idx} className="space-y-1">
                    <div className="flex justify-between text-xs font-medium">
                      <span className="text-slate-300 truncate">{feat.feature_name}</span>
                      <span className={isPos ? 'text-emerald-400' : 'text-rose-400'}>
                        {isPos ? '+' : ''}{(feat.contribution_score * 100).toFixed(0)}%
                      </span>
                    </div>
                    {/* Horizontal Bar */}
                    <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden flex">
                      <div 
                        className={`h-full rounded-full ${isPos ? 'bg-emerald-500' : 'bg-rose-500'}`} 
                        style={{ width: `${absPct}%` }}
                      />
                    </div>
                    <p className="text-[11px] text-slate-400 leading-tight">
                      {feat.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Counterfactual Guidance */}
          {decision.counterfactual_guidance && decision.counterfactual_guidance.length > 0 && (
            <div className="bg-amber-950/20 border border-amber-500/20 p-3.5 rounded-xl space-y-2">
              <h5 className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5" />
                Actionable Counterfactual Suggestions
              </h5>
              <ul className="space-y-1.5">
                {decision.counterfactual_guidance.map((tip, idx) => (
                  <li key={idx} className="text-xs text-amber-200/90 flex items-start gap-2">
                    <ArrowRight className="w-3 h-3 text-amber-400 shrink-0 mt-0.5" />
                    <span>{tip}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Relaxations & Scholarships */}
          {decision.applicable_relaxations?.length > 0 && (
            <div className="bg-sky-950/20 border border-sky-500/20 p-3 rounded-xl">
              <div className="text-xs font-bold text-sky-400 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                <Award className="w-3.5 h-3.5" />
                Applied Category Relaxations
              </div>
              <ul className="text-xs text-sky-200/90 space-y-1">
                {decision.applicable_relaxations.map((rel, idx) => (
                  <li key={idx}>• {rel}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

