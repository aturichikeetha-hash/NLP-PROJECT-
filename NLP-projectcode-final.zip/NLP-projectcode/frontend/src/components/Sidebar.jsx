import React from 'react';
import { 
  MessageSquareText, 
  ShieldCheck, 
  Compass, 
  User, 
  FileCheck2, 
  Briefcase, 
  LineChart, 
  BookOpen, 
  Users
} from 'lucide-react';

export default function Sidebar({ activeTab, setActiveTab, activeRole }) {
  const applicantNav = [
    { id: 'rag-chat', label: 'AI Admission Advisor (RAG)', icon: MessageSquareText, badge: 'Grounded' },
    { id: 'eligibility', label: 'Eligibility & XAI Inspector', icon: ShieldCheck, badge: 'Rule AI' },
    { id: 'recommender', label: 'Course & College Match', icon: Compass, badge: 'Smart' },
    { id: 'profile', label: 'Academic Profile Wizard', icon: User },
    { id: 'documents', label: 'Intelligent Doc Verifier', icon: FileCheck2 },
    { id: 'career', label: 'AI Career Guidance', icon: Briefcase },
  ];

  const officerNav = [
    { id: 'analytics', label: 'Cutoff Trends & Analytics', icon: LineChart, badge: '2021-2025' },
    { id: 'applicants-review', label: 'Applicant Management', icon: Users },
    { id: 'knowledge-repo', label: 'Knowledge Base & Policies', icon: BookOpen },
    { id: 'rag-chat', label: 'RAG Knowledge Query', icon: MessageSquareText },
  ];

  const currentNav = activeRole === 'officer' ? officerNav : applicantNav;

  return (
    <aside className="w-full md:w-64 shrink-0 space-y-4">
      <div className="glass-card rounded-2xl p-3 border border-slate-800 space-y-1">
        <div className="px-3 py-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">
          {activeRole === 'officer' ? 'Admission Officer Console' : 'Applicant Modules'}
        </div>
        
        {currentNav.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                isActive
                  ? activeRole === 'officer'
                    ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30'
                    : 'bg-sky-600/20 text-sky-300 border border-sky-500/30'
                  : 'text-slate-300 hover:bg-slate-900/60 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-2.5 truncate">
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? (activeRole === 'officer' ? 'text-indigo-400' : 'text-sky-400') : 'text-slate-400'}`} />
                <span className="truncate">{item.label}</span>
              </div>
              {item.badge && (
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 shrink-0">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </aside>
  );
}

