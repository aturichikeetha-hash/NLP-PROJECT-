import React from 'react';
import { CheckCircle2, AlertTriangle, XCircle, Clock } from 'lucide-react';

export default function EligibilityBadge({ status, size = 'md' }) {
  const sizeClasses = size === 'sm' 
    ? 'px-2 py-0.5 text-xs font-semibold' 
    : size === 'lg' 
    ? 'px-4 py-1.5 text-sm font-bold tracking-wide' 
    : 'px-3 py-1 text-xs font-semibold';

  if (status === 'ELIGIBLE') {
    return (
      <span className={`inline-flex items-center gap-1.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 ${sizeClasses}`}>
        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
        ELIGIBLE
      </span>
    );
  }
  if (status === 'CONDITIONAL') {
    return (
      <span className={`inline-flex items-center gap-1.5 rounded-full bg-amber-500/15 text-amber-400 border border-amber-500/30 ${sizeClasses}`}>
        <AlertTriangle className="w-4 h-4 text-amber-400" />
        CONDITIONAL / BORDERLINE
      </span>
    );
  }
  if (status === 'NOT_ELIGIBLE') {
    return (
      <span className={`inline-flex items-center gap-1.5 rounded-full bg-rose-500/15 text-rose-400 border border-rose-500/30 ${sizeClasses}`}>
        <XCircle className="w-4 h-4 text-rose-400" />
        NOT ELIGIBLE
      </span>
    );
  }
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full bg-slate-500/15 text-slate-400 border border-slate-500/30 ${sizeClasses}`}>
      <Clock className="w-4 h-4 text-slate-400" />
      {status || 'PENDING'}
    </span>
  );
}

