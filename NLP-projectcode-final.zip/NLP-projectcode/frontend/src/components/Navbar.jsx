import React from 'react';
import { 
  GraduationCap, 
  Sparkles, 
  UserCheck, 
  Shield, 
  Cpu, 
  Layers,
  ChevronRight,
  Database
} from 'lucide-react';

export default function Navbar({ activeRole, setActiveRole, currentUser }) {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800 bg-slate-950/85 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        
        {/* Brand Logo & Title */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-sky-500/20">
            <GraduationCap className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-base sm:text-lg text-white tracking-tight">
                AdmitAI Decision Support
              </span>
            </div>
            <p className="hidden md:block text-xs text-slate-400">
              Intelligent Admission Decision & Advisory Engine
            </p>
          </div>
        </div>

        {/* Center/Right Status & Role Switcher */}
        <div className="flex items-center gap-3">

          {/* Role Toggle */}
          <div className="flex items-center p-1 bg-slate-900 rounded-xl border border-slate-800">
            <button
              onClick={() => setActiveRole('applicant')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeRole === 'applicant'
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <UserCheck className="w-3.5 h-3.5" />
              <span>Applicant Portal</span>
            </button>
            <button
              onClick={() => setActiveRole('officer')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                activeRole === 'officer'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Officer Analytics</span>
            </button>
          </div>
        </div>

      </div>
    </header>
  );
}

