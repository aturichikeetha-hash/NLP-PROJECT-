const API_BASE = '/api/v1';

async function fetchJson(endpoint, options = {}) {
  const url = `${API_BASE}${endpoint}`;
  try {
    const res = await fetch(url, {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    });
    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.detail || `HTTP Error ${res.status}: ${res.statusText}`);
    }
    return await res.json();
  } catch (err) {
    console.error(`API Error on [${endpoint}]:`, err);
    throw err;
  }
}

export const api = {
  // Auth
  getDemoUsers: () => fetchJson('/auth/demo-users'),
  registerUser: (data) => fetchJson('/auth/register', { method: 'POST', body: JSON.stringify(data) }),

  // Profile
  getProfile: (userId) => fetchJson(`/profile/${userId}`),
  updateProfile: (userId, data) => fetchJson(`/profile/${userId}`, { method: 'PUT', body: JSON.stringify(data) }),

  // Eligibility & XAI
  evaluateEligibility: (payload) => fetchJson('/eligibility/evaluate', { method: 'POST', body: JSON.stringify(payload) }),

  // Course Recommendations
  getRecommendations: (params = {}) => {
    const searchParams = new URLSearchParams();
    if (params.user_id) searchParams.append('user_id', params.user_id);
    if (params.category) searchParams.append('category', params.category);
    if (params.percentile !== undefined) searchParams.append('percentile', params.percentile);
    return fetchJson(`/recommendations/?${searchParams.toString()}`);
  },

  // RAG Advisor & Search
  queryRAG: (query, provider = 'local', userId = null) => 
    fetchJson('/rag/query', {
      method: 'POST',
      body: JSON.stringify({ query, provider, user_id: userId })
    }),
  semanticSearch: (query, topK = 5) => fetchJson(`/rag/search?query=${encodeURIComponent(query)}&top_k=${topK}`),
  triggerReindex: () => fetchJson('/rag/reindex', { method: 'POST' }),

  // Documents
  uploadDocument: async (formData) => {
    const res = await fetch(`${API_BASE}/documents/upload`, {
      method: 'POST',
      body: formData, // let browser set boundary
    });
    if (!res.ok) throw new Error(`Upload failed with status ${res.status}`);
    return await res.json();
  },
  getDocumentStatus: (userId, degreeType = 'UG', category = 'General') => 
    fetchJson(`/documents/status/${userId}?degree_type=${degreeType}&category=${category}`),

  // Career Guidance
  getAllCareers: () => fetchJson('/career/'),
  getCareerByProgram: (programId) => fetchJson(`/career/${programId}`),

  // Officer Analytics
  getAnalyticsDashboard: () => fetchJson('/analytics/dashboard'),
  getCutoffTrends: (programId = 'PROG-BTECH-CSE') => fetchJson(`/analytics/cutoffs?program_id=${programId}`),
  getApplicantsSummary: () => fetchJson('/analytics/applicants-summary'),

  // Knowledge Base
  getPolicies: () => fetchJson('/knowledge/policies'),
  getColleges: () => fetchJson('/knowledge/colleges'),
  getScholarships: () => fetchJson('/knowledge/scholarships'),
  getCutoffs: () => fetchJson('/knowledge/cutoffs'),
};

