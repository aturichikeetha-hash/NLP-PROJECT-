import pytest
import sys
import os

# Set path so tests can import app
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.engines.eligibility_engine import eligibility_engine
from app.engines.recommender_engine import recommender_engine
from app.engines.doc_verifier import doc_verifier_engine
from app.engines.analytics_engine import analytics_engine
from app.rag.document_indexer import document_indexer
from app.rag.llm_service import llm_service

@pytest.fixture(scope="session", autouse=True)
def setup_rag_index():
    count = document_indexer.build_and_load_index()
    assert count > 0

def test_eligibility_btech_general_eligible():
    profile = {
        "twelfth_percentage": 88.0,
        "subjects_studied": ["Physics", "Mathematics", "Chemistry"],
        "entrance_percentile": 96.0,
        "entrance_rank": 12000,
        "reservation_category": "General"
    }
    decision = eligibility_engine.evaluate_eligibility(
        program_id="PROG-BTECH-CSE",
        college_id="COL-001",
        profile_data=profile
    )
    assert decision.status == "ELIGIBLE"
    assert decision.confidence_score >= 90.0
    assert len(decision.rule_checklist) >= 3
    assert len(decision.feature_importances) > 0
    assert all(r.is_satisfied for r in decision.rule_checklist)

def test_eligibility_mca_bsc_math():
    # Specific test for PDF Query: "Can I apply for MCA with a B.Sc. Mathematics degree?"
    profile = {
        "ug_degree": "B.Sc Mathematics",
        "ug_cgpa": 7.8,
        "subjects_studied": ["Mathematics", "Statistics", "Computer Science"],
        "entrance_percentile": 88.0,
        "entrance_rank": 380,
        "reservation_category": "General"
    }
    decision = eligibility_engine.evaluate_eligibility(
        program_id="PROG-MCA",
        college_id="COL-002",
        profile_data=profile
    )
    assert decision.status == "ELIGIBLE"
    assert decision.confidence_score >= 85.0
    # Check that Mathematics prerequisite is marked satisfied
    math_rule = next((r for r in decision.rule_checklist if "Mathematics" in r.rule_name), None)
    assert math_rule is not None
    assert math_rule.is_satisfied is True

def test_eligibility_relaxation_for_sc_st():
    profile = {
        "twelfth_percentage": 56.0, # Below 60% standard, but above 55% for SC
        "subjects_studied": ["Physics", "Mathematics", "Chemistry"],
        "entrance_percentile": 83.0,
        "entrance_rank": 52000,
        "reservation_category": "SC"
    }
    decision = eligibility_engine.evaluate_eligibility(
        program_id="PROG-BTECH-CSE",
        college_id="COL-001",
        profile_data=profile
    )
    assert decision.status == "ELIGIBLE"
    assert len(decision.applicable_relaxations) > 0

def test_rag_mca_query():
    query = "Can I apply for MCA with a B.Sc. Mathematics degree?"
    res = llm_service.generate_response(query=query)
    assert "MCA" in res.answer or "Mathematics" in res.answer
    assert len(res.citations) > 0
    assert res.confidence > 70.0
    assert len(res.suggested_followups) > 0

def test_rag_scholarships_query():
    query = "What scholarships are available for economically weaker students?"
    res = llm_service.generate_response(query=query)
    assert "Tuition Fee Waiver" in res.answer or "Scholarship" in res.answer or "EWS" in res.answer
    assert len(res.citations) > 0

def test_course_recommender():
    profile = {
        "reservation_category": "General",
        "entrance_percentile": 91.5,
        "twelfth_percentage": 86.0,
        "ug_cgpa": 8.0,
        "career_interests": ["Artificial Intelligence", "Cloud Computing"],
        "skills": ["Python", "Algorithms"]
    }
    reco = recommender_engine.recommend_programs(profile)
    assert reco.total_matches > 0
    total_options = len(reco.dream_options) + len(reco.target_options) + len(reco.safe_options)
    assert total_options > 0

def test_document_verification():
    res = doc_verifier_engine.verify_upload(
        file_name="12th_marks_sheet.pdf",
        file_size=250000,
        doc_type="12th_marksheet",
        user_name="Rahul Sharma"
    )
    assert res["is_valid"] is True
    assert res["verification_status"] == "VALIDATED"
    assert len(res["flags"]) > 0

    # Invalid extension test
    invalid_res = doc_verifier_engine.verify_upload(
        file_name="malicious_script.exe",
        file_size=50000,
        doc_type="10th_marksheet"
    )
    assert invalid_res["is_valid"] is False
    assert invalid_res["verification_status"] == "INVALID_FORMAT"

def test_analytics_dashboard():
    summary = analytics_engine.get_dashboard_summary()
    assert "overview" in summary
    assert summary["overview"]["total_colleges"] >= 3
    assert len(summary["category_distribution"]) == 5
    
    trends = analytics_engine.get_cutoff_trends("PROG-BTECH-CSE")
    assert len(trends["years"]) >= 3
    assert len(trends["series"]) >= 3

