from fastapi import APIRouter
import json
from app.config import DATA_DIR

router = APIRouter(prefix="/knowledge", tags=["Knowledge Base Repository"])

@router.get("/policies")
def list_policies():
    with open(DATA_DIR / "admission_policies.json", "r", encoding="utf-8") as f:
        return json.load(f)

@router.get("/colleges")
def list_colleges():
    with open(DATA_DIR / "colleges_and_programs.json", "r", encoding="utf-8") as f:
        return json.load(f)

@router.get("/scholarships")
def list_scholarships():
    with open(DATA_DIR / "scholarships_and_fees.json", "r", encoding="utf-8") as f:
        return json.load(f)

@router.get("/cutoffs")
def list_cutoffs():
    with open(DATA_DIR / "cutoffs_2021_2025.json", "r", encoding="utf-8") as f:
        return json.load(f)

