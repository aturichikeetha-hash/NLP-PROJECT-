from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.applicant import AcademicProfile
from app.schemas.eligibility import EligibilityCheckRequest, EligibilityDecisionResponse
from app.engines.eligibility_engine import eligibility_engine

router = APIRouter(prefix="/eligibility", tags=["Eligibility & XAI"])

@router.post("/evaluate", response_model=EligibilityDecisionResponse)
def evaluate_eligibility(req: EligibilityCheckRequest, db: Session = Depends(get_db)):
    profile_dict = {}
    
    if req.user_id:
        prof = db.query(AcademicProfile).filter(AcademicProfile.user_id == req.user_id).first()
        if prof:
            profile_dict = {
                "tenth_percentage": prof.tenth_percentage,
                "twelfth_percentage": prof.twelfth_percentage,
                "ug_cgpa": prof.ug_cgpa,
                "ug_degree": prof.ug_degree,
                "subjects_studied": prof.subjects_studied or [],
                "entrance_exam_name": prof.entrance_exam_name,
                "entrance_percentile": prof.entrance_percentile,
                "entrance_rank": prof.entrance_rank,
                "reservation_category": prof.reservation_category,
                "is_pwd": prof.is_pwd,
                "annual_family_income": prof.annual_family_income
            }

    # Apply any request-level sandbox overrides
    if req.twelfth_percentage is not None:
        profile_dict["twelfth_percentage"] = req.twelfth_percentage
    if req.ug_cgpa is not None:
        profile_dict["ug_cgpa"] = req.ug_cgpa
    if req.ug_degree is not None:
        profile_dict["ug_degree"] = req.ug_degree
    if req.subjects_studied is not None:
        profile_dict["subjects_studied"] = req.subjects_studied
    if req.entrance_percentile is not None:
        profile_dict["entrance_percentile"] = req.entrance_percentile
    if req.reservation_category is not None:
        profile_dict["reservation_category"] = req.reservation_category
    if req.is_pwd is not None:
        profile_dict["is_pwd"] = req.is_pwd

    # Defaults if missing
    if "reservation_category" not in profile_dict:
        profile_dict["reservation_category"] = "General"
    if "twelfth_percentage" not in profile_dict:
        profile_dict["twelfth_percentage"] = 85.0
    if "entrance_percentile" not in profile_dict:
        profile_dict["entrance_percentile"] = 92.0
    if "subjects_studied" not in profile_dict:
        profile_dict["subjects_studied"] = ["Physics", "Mathematics", "Chemistry"]

    try:
        decision = eligibility_engine.evaluate_eligibility(
            program_id=req.program_id,
            college_id=req.college_id,
            profile_data=profile_dict
        )
        return decision
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

