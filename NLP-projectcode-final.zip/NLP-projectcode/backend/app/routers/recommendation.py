from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional
from app.database import get_db
from app.models.applicant import AcademicProfile
from app.schemas.recommendation import RecommendationResponse
from app.engines.recommender_engine import recommender_engine

router = APIRouter(prefix="/recommendations", tags=["Course Recommendations"])

@router.get("/", response_model=RecommendationResponse)
def get_recommendations(
    user_id: Optional[int] = Query(None),
    category: Optional[str] = Query(None),
    percentile: Optional[float] = Query(None),
    db: Session = Depends(get_db)
):
    profile_dict = {
        "reservation_category": category or "General",
        "entrance_percentile": percentile or 88.0,
        "twelfth_percentage": 85.0,
        "ug_cgpa": 8.0,
        "career_interests": ["Artificial Intelligence", "Data Science", "Software Engineering"],
        "skills": ["Python", "Algorithms", "Mathematics"],
        "preferred_degrees": ["B.Tech", "MCA", "MBA"]
    }

    if user_id:
        prof = db.query(AcademicProfile).filter(AcademicProfile.user_id == user_id).first()
        if prof:
            profile_dict = {
                "reservation_category": category or prof.reservation_category,
                "entrance_percentile": percentile if percentile is not None else prof.entrance_percentile,
                "twelfth_percentage": prof.twelfth_percentage,
                "ug_cgpa": prof.ug_cgpa,
                "career_interests": prof.career_interests or ["Artificial Intelligence", "Software Engineering"],
                "skills": prof.skills or ["Python", "Algorithms"],
                "preferred_degrees": prof.preferred_degrees or ["B.Tech", "MCA", "MBA"]
            }

    return recommender_engine.recommend_programs(profile_dict)

