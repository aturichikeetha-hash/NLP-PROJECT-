from fastapi import APIRouter, HTTPException
import json
from typing import List, Dict, Any, Optional
from app.config import DATA_DIR

router = APIRouter(prefix="/career", tags=["AI Career Guidance"])

def load_career_data():
    with open(DATA_DIR / "career_paths.json", "r", encoding="utf-8") as f:
        return json.load(f)

@router.get("/")
def list_all_career_pathways():
    return load_career_data()

@router.get("/{program_id}")
def get_career_guidance_for_program(program_id: str):
    data = load_career_data()
    for cp in data:
        if cp.get("program_id") == program_id:
            return cp
    # Default fallback
    if data:
        return data[0]
    raise HTTPException(status_code=404, detail="Career pathway not found")

