from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.applicant import User, AcademicProfile
from app.schemas.profile import UserCreate, UserResponse

router = APIRouter(prefix="/auth", tags=["Authentication & Users"])

@router.post("/register", response_model=UserResponse)
def register_user(user_in: UserCreate, db: Session = Depends(get_db)):
    existing = db.query(User).filter(User.email == user_in.email).first()
    if existing:
        return existing
    new_user = User(email=user_in.email, full_name=user_in.full_name, role=user_in.role)
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    
    # Initialize default academic profile for applicants
    if new_user.role == "applicant":
        profile = AcademicProfile(
            user_id=new_user.id,
            tenth_percentage=88.0,
            twelfth_percentage=85.5,
            ug_cgpa=8.2,
            ug_degree="B.Sc Mathematics",
            subjects_studied=["Mathematics", "Physics", "Chemistry", "Computer Science"],
            entrance_exam_name="JEE Main",
            entrance_percentile=93.8,
            entrance_rank=18400,
            reservation_category="General",
            career_interests=["Artificial Intelligence", "Software Engineering", "Cloud Computing"],
            skills=["Python", "Algorithms", "Mathematics", "Problem Solving"]
        )
        db.add(profile)
        db.commit()
        
    return new_user

@router.get("/demo-users")
def get_demo_users(db: Session = Depends(get_db)):
    # Ensure standard default demo accounts exist
    applicant = db.query(User).filter(User.email == "applicant@example.com").first()
    if not applicant:
        applicant = User(email="applicant@example.com", full_name="Rahul Sharma", role="applicant")
        db.add(applicant)
        db.commit()
        db.refresh(applicant)
        prof = AcademicProfile(
            user_id=applicant.id,
            tenth_percentage=89.5,
            twelfth_percentage=86.0,
            ug_cgpa=8.4,
            ug_degree="B.Sc Mathematics",
            subjects_studied=["Mathematics", "Physics", "Chemistry", "Computer Science"],
            entrance_exam_name="JEE Main",
            entrance_percentile=93.8,
            entrance_rank=18400,
            reservation_category="General",
            annual_family_income=550000.0,
            career_interests=["Artificial Intelligence", "Data Science", "Cloud Architecture"],
            skills=["Python", "Data Structures", "Mathematics", "Machine Learning"]
        )
        db.add(prof)
        db.commit()

    officer = db.query(User).filter(User.email == "officer@university.edu").first()
    if not officer:
        officer = User(email="officer@university.edu", full_name="Dr. Aris Thorne (Dean of Admissions)", role="officer")
        db.add(officer)
        db.commit()
        db.refresh(officer)

    return {
        "applicant": {"id": applicant.id, "email": applicant.email, "name": applicant.full_name, "role": "applicant"},
        "officer": {"id": officer.id, "email": officer.email, "name": officer.full_name, "role": "officer"}
    }

