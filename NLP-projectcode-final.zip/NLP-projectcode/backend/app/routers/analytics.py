from fastapi import APIRouter, Query, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.engines.analytics_engine import analytics_engine
from app.models.application import Application, UploadedDocument
from app.models.applicant import User

router = APIRouter(prefix="/analytics", tags=["Officer Analytics & Reports"])

@router.get("/dashboard")
def get_analytics_dashboard():
    return analytics_engine.get_dashboard_summary()

@router.get("/cutoffs")
def get_cutoff_trend_series(program_id: str = Query("PROG-BTECH-CSE")):
    return analytics_engine.get_cutoff_trends(program_id)

@router.get("/applicants-summary")
def get_applicants_summary(db: Session = Depends(get_db)):
    users = db.query(User).filter(User.role == "applicant").all()
    records = []
    for u in users:
        docs = db.query(UploadedDocument).filter(UploadedDocument.user_id == u.id).all()
        records.append({
            "user_id": u.id,
            "name": u.full_name,
            "email": u.email,
            "documents_uploaded": len(docs),
            "verification_status": "VERIFIED" if len(docs) >= 3 else "PENDING_DOCUMENTS",
            "registered_at": u.created_at.strftime("%Y-%m-%d %H:%M") if u.created_at else ""
        })
    return {"total_registered_applicants": len(records), "applicants": records}

