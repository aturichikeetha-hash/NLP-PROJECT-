from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional
import os
import shutil
from pathlib import Path
from app.database import get_db
from app.models.applicant import User
from app.models.application import UploadedDocument
from app.engines.doc_verifier import doc_verifier_engine

router = APIRouter(prefix="/documents", tags=["Document Verification"])

UPLOAD_DIR = Path(__file__).resolve().parent.parent / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

@router.post("/upload")
async def upload_document(
    user_id: int = Form(...),
    doc_type: str = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.id == user_id).first()
    user_name = user.full_name if user else ""

    file_bytes = await file.read()
    file_size = len(file_bytes)
    file_name = file.filename or "uploaded_doc.pdf"

    # Verify upload using validation engine
    verification = doc_verifier_engine.verify_upload(
        file_name=file_name,
        file_size=file_size,
        doc_type=doc_type,
        user_name=user_name
    )

    # Save to disk
    dest_path = UPLOAD_DIR / f"{user_id}_{doc_type}_{file_name}"
    with open(dest_path, "wb") as f:
        f.write(file_bytes)

    # Upsert or insert database record
    existing_doc = db.query(UploadedDocument).filter(
        UploadedDocument.user_id == user_id,
        UploadedDocument.doc_type == doc_type
    ).first()

    if existing_doc:
        existing_doc.file_name = file_name
        existing_doc.file_path = str(dest_path)
        existing_doc.file_size_bytes = file_size
        existing_doc.verification_status = verification["verification_status"]
        existing_doc.extracted_metadata = verification["extracted_metadata"]
        existing_doc.validation_flags = verification["flags"]
        doc_record = existing_doc
    else:
        doc_record = UploadedDocument(
            user_id=user_id,
            doc_type=doc_type,
            file_name=file_name,
            file_path=str(dest_path),
            file_size_bytes=file_size,
            mime_type=file.content_type or "application/pdf",
            verification_status=verification["verification_status"],
            extracted_metadata=verification["extracted_metadata"],
            validation_flags=verification["flags"]
        )
        db.add(doc_record)

    db.commit()
    db.refresh(doc_record)

    return {
        "doc_id": doc_record.id,
        "doc_type": doc_type,
        "file_name": file_name,
        "verification_status": doc_record.verification_status,
        "flags": doc_record.validation_flags,
        "extracted_metadata": doc_record.extracted_metadata
    }

@router.get("/status/{user_id}")
def get_user_document_status(
    user_id: int, 
    degree_type: str = "UG", 
    category: str = "General",
    db: Session = Depends(get_db)
):
    user_docs = db.query(UploadedDocument).filter(UploadedDocument.user_id == user_id).all()
    uploaded_types = [d.doc_type for d in user_docs]
    
    missing_analysis = doc_verifier_engine.check_missing_documents(
        uploaded_doc_types=uploaded_types,
        degree_type=degree_type,
        category=category
    )

    doc_details = []
    for d in user_docs:
        doc_details.append({
            "id": d.id,
            "doc_type": d.doc_type,
            "file_name": d.file_name,
            "file_size_kb": round(d.file_size_bytes / 1024, 1),
            "status": d.verification_status,
            "flags": d.validation_flags,
            "uploaded_at": d.uploaded_at.isoformat() if d.uploaded_at else ""
        })

    return {
        "user_id": user_id,
        "uploaded_documents": doc_details,
        "analysis": missing_analysis
    }

