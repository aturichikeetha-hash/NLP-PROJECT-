from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.applicant import User, AcademicProfile
from app.schemas.profile import AcademicProfileResponse, AcademicProfileUpdate

router = APIRouter(prefix="/profile", tags=["Academic Profile"])

@router.get("/{user_id}", response_model=AcademicProfileResponse)
def get_user_profile(user_id: int, db: Session = Depends(get_db)):
    prof = db.query(AcademicProfile).filter(AcademicProfile.user_id == user_id).first()
    if not prof:
        # Create default profile if not exists
        prof = AcademicProfile(
            user_id=user_id,
            tenth_percentage=88.0,
            twelfth_percentage=85.5,
            ug_cgpa=8.2,
            ug_degree="B.Sc Mathematics",
            subjects_studied=["Mathematics", "Physics", "Chemistry", "Computer Science"],
            entrance_exam_name="JEE Main",
            entrance_percentile=93.8,
            entrance_rank=18400,
            reservation_category="General",
            career_interests=["Artificial Intelligence", "Data Science", "Cloud Architecture"],
            skills=["Python", "Data Structures", "Mathematics"]
        )
        db.add(prof)
        db.commit()
        db.refresh(prof)
    return prof

@router.put("/{user_id}", response_model=AcademicProfileResponse)
def update_user_profile(user_id: int, profile_in: AcademicProfileUpdate, db: Session = Depends(get_db)):
    prof = db.query(AcademicProfile).filter(AcademicProfile.user_id == user_id).first()
    if not prof:
        prof = AcademicProfile(user_id=user_id)
        db.add(prof)

    for field, val in profile_in.dict(exclude_unset=True).items():
        setattr(prof, field, val)

    db.commit()
    db.refresh(prof)
    return prof

