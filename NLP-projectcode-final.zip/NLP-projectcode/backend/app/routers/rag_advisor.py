from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.knowledge import ChatHistory
from app.schemas.rag import RAGQueryRequest, RAGQueryResponse, SemanticSearchResponse, SearchResultItem
from app.rag.llm_service import llm_service
from app.rag.vector_store import hybrid_vector_store
from app.rag.document_indexer import document_indexer

router = APIRouter(prefix="/rag", tags=["RAG & Semantic Search"])

@router.post("/query", response_model=RAGQueryResponse)
def query_rag_advisor(req: RAGQueryRequest, db: Session = Depends(get_db)):
    response = llm_service.generate_response(
        query=req.query,
        top_k=req.top_k,
        provider=req.provider
    )

    # Persist chat history if user_id is provided
    if req.user_id:
        chat_rec = ChatHistory(
            user_id=req.user_id,
            query=req.query,
            response=response.answer,
            citations=[c.dict() for c in response.citations],
            model_used=response.model_name
        )
        db.add(chat_rec)
        db.commit()

    return response

@router.get("/search", response_model=SemanticSearchResponse)
def semantic_search(query: str = Query(..., min_length=2), top_k: int = 5):
    results = hybrid_vector_store.search(query, top_k=top_k)
    items = []
    for chunk, score in results:
        items.append(SearchResultItem(
            doc_id=chunk["doc_id"],
            title=chunk["title"],
            doc_type=chunk["doc_type"],
            snippet=chunk["snippet"],
            score=score,
            metadata={"section": chunk.get("section", ""), "keywords": chunk.get("keywords", [])}
        ))
    return SemanticSearchResponse(query=query, total_results=len(items), results=items)

@router.post("/reindex")
def trigger_reindex():
    count = document_indexer.build_and_load_index()
    return {"status": "SUCCESS", "message": f"Successfully reindexed {count} knowledge documents."}

