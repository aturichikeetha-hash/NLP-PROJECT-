from sqlalchemy import Column, Integer, String, Float, Boolean, JSON, DateTime
from datetime import datetime
from app.database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    full_name = Column(String, nullable=False)
    role = Column(String, default="applicant")  # "applicant", "officer", "admin"
    created_at = Column(DateTime, default=datetime.utcnow)

class AcademicProfile(Base):
    __tablename__ = "academic_profiles"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, index=True, nullable=False)
    tenth_percentage = Column(Float, default=0.0)
    twelfth_percentage = Column(Float, default=0.0)
    ug_cgpa = Column(Float, default=0.0)
    ug_degree = Column(String, default="")  # e.g., "B.Sc Mathematics", "BCA", "B.Tech"
    subjects_studied = Column(JSON, default=list)  # ["Mathematics", "Physics", "Chemistry", "Computer Science"]
    
    # Entrance examination scores & percentiles
    entrance_exam_name = Column(String, default="JEE Main")  # "JEE Main", "GATE", "CAT", "NIMCET", "State CET"
    entrance_score = Column(Float, default=0.0)
    entrance_percentile = Column(Float, default=0.0)
    entrance_rank = Column(Integer, default=0)
    
    # Category & Demographics
    reservation_category = Column(String, default="General")  # "General", "OBC-NCL", "SC", "ST", "EWS"
    is_pwd = Column(Boolean, default=False)
    state_domicile = Column(String, default="Home State")
    annual_family_income = Column(Float, default=500000.0)
    
    # Preferences & Skills
    career_interests = Column(JSON, default=list)  # ["Artificial Intelligence", "Cloud Computing", "Management"]
    skills = Column(JSON, default=list)            # ["Python", "Algorithms", "Mathematics", "Problem Solving"]
    preferred_locations = Column(JSON, default=list)
    preferred_degrees = Column(JSON, default=list) # ["B.Tech", "MCA", "MBA"]
    
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

