from app.models.applicant import User, AcademicProfile
from app.models.application import Application, UploadedDocument
from app.models.knowledge import KnowledgeChunk, ChatHistory

__all__ = ["User", "AcademicProfile", "Application", "UploadedDocument", "KnowledgeChunk", "ChatHistory"]

