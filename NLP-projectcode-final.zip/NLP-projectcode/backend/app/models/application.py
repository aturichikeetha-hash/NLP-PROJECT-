from sqlalchemy import Column, Integer, String, Float, JSON, DateTime, ForeignKey
from datetime import datetime
from app.database import Base

class Application(Base):
    __tablename__ = "applications"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, index=True, nullable=False)
    college_id = Column(String, nullable=False)
    program_id = Column(String, nullable=False)
    program_name = Column(String, nullable=False)
    degree = Column(String, nullable=False)
    
    # Eligibility & XAI evaluation results
    eligibility_status = Column(String, default="PENDING")  # "ELIGIBLE", "CONDITIONAL", "NOT_ELIGIBLE"
    confidence_score = Column(Float, default=0.0)
    xai_explanation = Column(JSON, default=dict)
    
    # Application lifecycle
    application_status = Column(String, default="SUBMITTED") # "DRAFT", "SUBMITTED", "UNDER_REVIEW", "APPROVED", "REJECTED"
    officer_remarks = Column(String, default="")
    submitted_at = Column(DateTime, default=datetime.utcnow)
    reviewed_at = Column(DateTime, nullable=True)

class UploadedDocument(Base):
    __tablename__ = "uploaded_documents"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, index=True, nullable=False)
    doc_type = Column(String, nullable=False)  # "10th_marksheet", "12th_marksheet", "ug_degree", "entrance_scorecard", "category_cert", "income_cert"
    file_name = Column(String, nullable=False)
    file_path = Column(String, nullable=False)
    file_size_bytes = Column(Integer, default=0)
    mime_type = Column(String, default="application/pdf")
    
    # Verification Engine Status
    verification_status = Column(String, default="VALIDATED") # "VALIDATED", "INVALID_FORMAT", "MISSING_INFO", "MANUAL_REVIEW_NEEDED"
    extracted_metadata = Column(JSON, default=dict)
    validation_flags = Column(JSON, default=list) # ["Name match verified", "Roll number detected", "Clear signature"]
    uploaded_at = Column(DateTime, default=datetime.utcnow)

