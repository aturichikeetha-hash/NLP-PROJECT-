from sqlalchemy import Column, Integer, String, JSON, DateTime, Text
from datetime import datetime
from app.database import Base

class KnowledgeChunk(Base):
    __tablename__ = "knowledge_chunks"

    id = Column(Integer, primary_key=True, index=True)
    doc_id = Column(String, index=True, nullable=False)
    doc_type = Column(String, nullable=False) # "policy", "program", "scholarship", "cutoff", "career"
    title = Column(String, nullable=False)
    content = Column(Text, nullable=False)
    metadata_json = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow)

class ChatHistory(Base):
    __tablename__ = "chat_history"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, index=True, nullable=False)
    query = Column(Text, nullable=False)
    response = Column(Text, nullable=False)
    citations = Column(JSON, default=list)
    model_used = Column(String, default="hybrid-rag-engine")
    timestamp = Column(DateTime, default=datetime.utcnow)

