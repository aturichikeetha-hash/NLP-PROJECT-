import json
from pathlib import Path
from typing import Dict, Any, List, Optional
from app.config import DATA_DIR
from app.schemas.eligibility import RuleCheckItem, EligibilityDecisionResponse, FeatureImportanceItem

class EligibilityEngine:
    def __init__(self):
        self._load_datasets()

    def _load_datasets(self):
        with open(DATA_DIR / "admission_policies.json", "r", encoding="utf-8") as f:
            self.policies = json.load(f)
        with open(DATA_DIR / "colleges_and_programs.json", "r", encoding="utf-8") as f:
            self.colleges = json.load(f)
        with open(DATA_DIR / "cutoffs_2021_2025.json", "r", encoding="utf-8") as f:
            self.cutoffs = json.load(f)
        with open(DATA_DIR / "scholarships_and_fees.json", "r", encoding="utf-8") as f:
            self.scholarships = json.load(f)

    def find_program_and_college(self, program_id: str, college_id: Optional[str] = None):
        for col in self.colleges:
            if college_id and col["college_id"] != college_id:
                continue
            for prog in col["programs"]:
                if prog["program_id"] == program_id:
                    return prog, col
        # Fallback to first matching program across any college
        for col in self.colleges:
            for prog in col["programs"]:
                if prog["program_id"] == program_id:
                    return prog, col
        return None, None

    def evaluate_eligibility(
        self,
        program_id: str,
        college_id: Optional[str],
        profile_data: Dict[str, Any]
    ) -> EligibilityDecisionResponse:
        prog, college = self.find_program_and_college(program_id, college_id)
        if not prog or not college:
            raise ValueError(f"Program with ID {program_id} not found in database.")

        degree = prog.get("degree", "B.Tech")
        category = profile_data.get("reservation_category", "General")
        is_reserved = category in ["OBC-NCL", "SC", "ST", "PwD", "EWS"]
        is_sc_st = category in ["SC", "ST"]
        is_pwd = profile_data.get("is_pwd", False)
        
        twelfth_pct = float(profile_data.get("twelfth_percentage", 0.0))
        ug_cgpa = float(profile_data.get("ug_cgpa", 0.0))
        ug_degree = profile_data.get("ug_degree", "").strip()
        subjects = [s.strip().lower() for s in profile_data.get("subjects_studied", [])]
        entrance_percentile = float(profile_data.get("entrance_percentile", 0.0))
        entrance_rank = int(profile_data.get("entrance_rank", 0))
        
        rule_checklist: List[RuleCheckItem] = []
        feature_importances: List[FeatureImportanceItem] = []
        counterfactuals: List[str] = []
        applicable_relaxations: List[str] = []
        applicable_scholarships: List[str] = []

        total_weight = 0.0
        earned_weight = 0.0

        # -------------------------------------------------------------
        # Rule 1: Qualifying Academic Percentage (12th or UG)
        # -------------------------------------------------------------
        if degree in ["B.Tech", "B.Sc"]:
            min_req = prog.get("min_12th_percentage", 60.0)
            if is_reserved or is_pwd:
                min_req -= 5.0 # Statutory 5% relaxation
                applicable_relaxations.append(f"5% relaxation applied on 10+2 marks for {category} category (Threshold: {min_req}%).")
            
            passed = twelfth_pct >= min_req
            weight = 3.0
            total_weight += weight
            if passed:
                earned_weight += weight
                feature_importances.append(FeatureImportanceItem(
                    feature_name="10+2 Academic Percentage",
                    contribution_score=0.35,
                    description=f"Scored {twelfth_pct}% exceeding minimum requirement of {min_req}%"
                ))
            else:
                feature_importances.append(FeatureImportanceItem(
                    feature_name="10+2 Academic Percentage",
                    contribution_score=-0.40,
                    description=f"Scored {twelfth_pct}% which is below the minimum requirement of {min_req}%"
                ))
                shortfall = round(min_req - twelfth_pct, 1)
                counterfactuals.append(f"Improve 10+2 qualifying aggregate score by at least {shortfall}% to satisfy academic eligibility.")

            rule_checklist.append(RuleCheckItem(
                rule_name="Qualifying 10+2 Aggregate",
                criterion=f"Minimum {min_req}% aggregate in 10+2 / Intermediate",
                student_value=f"{twelfth_pct}%",
                is_satisfied=passed,
                details=f"Candidate scored {twelfth_pct}% (Required: {min_req}% for {category})",
                weight=weight
            ))

        elif degree in ["MCA", "MBA", "M.Tech"]:
            min_cgpa = prog.get("min_ug_cgpa", 5.5)
            if is_sc_st or is_pwd:
                min_cgpa -= 0.5
                applicable_relaxations.append(f"0.5 CGPA (5%) relaxation applied on graduation for {category} category.")
            
            passed = ug_cgpa >= min_cgpa
            weight = 3.0
            total_weight += weight
            if passed:
                earned_weight += weight
                feature_importances.append(FeatureImportanceItem(
                    feature_name="Undergraduate Degree CGPA",
                    contribution_score=0.35,
                    description=f"UG CGPA of {ug_cgpa}/10.0 meets requirement of {min_cgpa}"
                ))
            else:
                feature_importances.append(FeatureImportanceItem(
                    feature_name="Undergraduate Degree CGPA",
                    contribution_score=-0.40,
                    description=f"UG CGPA of {ug_cgpa} is below minimum requirement of {min_cgpa}"
                ))
                counterfactuals.append(f"Maintain at least {min_cgpa} CGPA in graduation to be eligible for PG admissions.")

            rule_checklist.append(RuleCheckItem(
                rule_name="Undergraduate Degree Marks",
                criterion=f"Minimum {min_cgpa} CGPA (or 50% / 45% for SC/ST)",
                student_value=f"{ug_cgpa} CGPA (Degree: {ug_degree or 'Graduation'})",
                is_satisfied=passed,
                details=f"UG CGPA evaluated as {ug_cgpa} vs {min_cgpa} threshold.",
                weight=weight
            ))

        # -------------------------------------------------------------
        # Rule 2: Mandatory Subject Eligibility Check (e.g. Maths for MCA, PCM for B.Tech)
        # -------------------------------------------------------------
        mandatory_subs = prog.get("mandatory_subjects", [])
        subjects_text = " ".join(subjects) + " " + ug_degree.lower()
        
        if degree == "B.Tech":
            has_physics = "physics" in subjects_text
            has_math = "mathematics" in subjects_text or "math" in subjects_text or "maths" in subjects_text
            sub_passed = has_physics and has_math
            sub_val = "Physics & Mathematics" if sub_passed else ("Missing " + ("Physics " if not has_physics else "") + ("Mathematics" if not has_math else ""))
            
            weight = 2.5
            total_weight += weight
            if sub_passed:
                earned_weight += weight
                feature_importances.append(FeatureImportanceItem(
                    feature_name="Subject Prerequisite (Physics + Maths)",
                    contribution_score=0.25,
                    description="Studied mandatory Physics and Mathematics at 10+2"
                ))
            else:
                feature_importances.append(FeatureImportanceItem(
                    feature_name="Subject Prerequisite (Physics + Maths)",
                    contribution_score=-0.35,
                    description="Mandatory Physics and Mathematics not found in profile subjects"
                ))
                counterfactuals.append("Physics and Mathematics are compulsory prerequisites for Engineering (B.Tech).")

            rule_checklist.append(RuleCheckItem(
                rule_name="Mandatory High School Subjects",
                criterion="Physics and Mathematics compulsory at 10+2",
                student_value=sub_val,
                is_satisfied=sub_passed,
                details="Verified Physics & Mathematics subject compliance.",
                weight=weight
            ))

        elif degree == "MCA":
            # Document specific question: "Can I apply for MCA with a B.Sc. Mathematics degree?"
            has_math = "mathematics" in subjects_text or "math" in subjects_text or "maths" in subjects_text or "bca" in subjects_text or "b.sc" in subjects_text
            weight = 2.5
            total_weight += weight
            if has_math:
                earned_weight += weight
                feature_importances.append(FeatureImportanceItem(
                    feature_name="MCA Mathematics Prerequisite",
                    contribution_score=0.30,
                    description="Studied Mathematics at 10+2 or Graduation Level (Eligible degree path)"
                ))
            else:
                feature_importances.append(FeatureImportanceItem(
                    feature_name="MCA Mathematics Prerequisite",
                    contribution_score=-0.35,
                    description="Mathematics at 10+2 or Degree level is mandatory for MCA"
                ))
                counterfactuals.append("Candidates must have studied Mathematics at 10+2 or Degree level to be eligible for MCA.")

            rule_checklist.append(RuleCheckItem(
                rule_name="MCA Mathematics Requirement",
                criterion="Mathematics at 10+2 or Graduation Level (BCA/B.Sc Maths/B.Tech/etc.)",
                student_value=f"Degree: {ug_degree or 'N/A'}, Subjects: {', '.join(profile_data.get('subjects_studied', []))}",
                is_satisfied=has_math,
                details="Verified AICTE / University MCA Mathematics prerequisite rule.",
                weight=weight
            ))

        # -------------------------------------------------------------
        # Rule 3: Entrance Exam & Historical Cutoff Evaluation
        # -------------------------------------------------------------
        prog_cutoff_entry = next((c for c in self.cutoffs if c["program_id"] == program_id), None)
        latest_cutoff = 75.0 # default
        if prog_cutoff_entry and prog_cutoff_entry.get("history"):
            latest_year_data = prog_cutoff_entry["history"][0]
            cat_data = latest_year_data.get(category, latest_year_data.get("General", {}))
            latest_cutoff = cat_data.get("min_percentile", 75.0)

        cutoff_passed = entrance_percentile >= latest_cutoff
        weight = 3.5
        total_weight += weight

        if cutoff_passed:
            earned_weight += weight
            feature_importances.append(FeatureImportanceItem(
                feature_name="Entrance Exam Percentile",
                contribution_score=0.35,
                description=f"Percentile of {entrance_percentile}% is above {category} cutoff ({latest_cutoff}%)"
            ))
        else:
            diff = round(latest_cutoff - entrance_percentile, 2)
            feature_importances.append(FeatureImportanceItem(
                feature_name="Entrance Exam Percentile",
                contribution_score=-0.30,
                description=f"Percentile of {entrance_percentile}% is {diff}% below the {category} cutoff threshold ({latest_cutoff}%)"
            ))
            counterfactuals.append(f"An increase of {diff}% in entrance percentile would bridge the cutoff gap for {college['college_name']}.")

        rule_checklist.append(RuleCheckItem(
            rule_name="Entrance Examination Cutoff",
            criterion=f"Minimum {latest_cutoff}% percentile for {category} category in {prog.get('accepted_exams', ['Entrance Exam'])[0]}",
            student_value=f"{entrance_percentile}% (Rank: {entrance_rank})",
            is_satisfied=cutoff_passed,
            details=f"Candidate's {entrance_percentile}% vs {category} category closing cutoff of {latest_cutoff}%.",
            weight=weight
        ))

        # -------------------------------------------------------------
        # Rule 4: Mandatory Document & Category Verification Readiness
        # -------------------------------------------------------------
        weight = 1.0
        total_weight += weight
        earned_weight += weight
        rule_checklist.append(RuleCheckItem(
            rule_name="Reservation & Document Validity",
            criterion=f"Valid {category} Certificate & Academic Credentials",
            student_value=f"Category: {category}, PwD: {is_pwd}",
            is_satisfied=True,
            details=f"Eligible for {category} seat allocation subject to standard document verification.",
            weight=weight
        ))

        # -------------------------------------------------------------
        # Calculate Explainable Confidence Score & Overall Status
        # -------------------------------------------------------------
        confidence = round((earned_weight / total_weight) * 100.0, 1) if total_weight > 0 else 0.0
        all_satisfied = all(r.is_satisfied for r in rule_checklist)
        
        if all_satisfied and confidence >= 85.0:
            status = "ELIGIBLE"
            summary_reason = f"Candidate satisfies all statutory and institution-specific eligibility criteria with a high confidence score of {confidence}%."
        elif confidence >= 60.0:
            status = "CONDITIONAL"
            summary_reason = f"Candidate satisfies core qualifications but falls near cutoff boundaries or requires specific prerequisite verification (Confidence: {confidence}%)."
        else:
            status = "NOT_ELIGIBLE"
            summary_reason = f"Candidate does not meet one or more mandatory eligibility requirements (Confidence: {confidence}%)."

        # Scholarships matched
        family_income = float(profile_data.get("annual_family_income", 500000.0))
        for sch in self.scholarships:
            elig = sch["eligibility_criteria"]
            if family_income <= (elig.get("family_income_limit_lpa", 5.0) * 100000):
                applicable_scholarships.append(f"{sch['name']} - {sch['benefit']}")

        return EligibilityDecisionResponse(
            program_id=program_id,
            program_name=prog["program_name"],
            college_name=college["college_name"],
            degree=degree,
            status=status,
            confidence_score=confidence,
            summary_reason=summary_reason,
            rule_checklist=rule_checklist,
            feature_importances=feature_importances,
            counterfactual_guidance=counterfactuals,
            applicable_relaxations=applicable_relaxations,
            applicable_scholarships=applicable_scholarships
        )

eligibility_engine = EligibilityEngine()

