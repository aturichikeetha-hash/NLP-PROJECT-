import json
import numpy as np
from typing import Dict, Any, List, Optional
from app.config import DATA_DIR
from app.schemas.recommendation import RecommendationItem, RecommendationResponse
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class CourseRecommenderEngine:
    def __init__(self):
        self._load_data()

    def _load_data(self):
        with open(DATA_DIR / "colleges_and_programs.json", "r", encoding="utf-8") as f:
            self.colleges = json.load(f)
        with open(DATA_DIR / "cutoffs_2021_2025.json", "r", encoding="utf-8") as f:
            self.cutoffs = json.load(f)
        with open(DATA_DIR / "career_paths.json", "r", encoding="utf-8") as f:
            self.career_paths = json.load(f)

    def get_program_career_paths(self, program_id: str) -> List[str]:
        for cp in self.career_paths:
            if cp.get("program_id") == program_id:
                return [r["title"] for r in cp.get("primary_career_roles", [])]
        return ["Software Engineer", "Systems Analyst", "Technical Consultant"]

    def recommend_programs(self, profile_data: Dict[str, Any]) -> RecommendationResponse:
        user_category = profile_data.get("reservation_category", "General")
        user_percentile = float(profile_data.get("entrance_percentile", 85.0))
        user_twelfth = float(profile_data.get("twelfth_percentage", 80.0))
        user_ug_cgpa = float(profile_data.get("ug_cgpa", 7.5))
        user_interests = profile_data.get("career_interests", ["Technology", "Engineering"])
        user_skills = profile_data.get("skills", ["Problem Solving", "Programming"])
        preferred_degrees = profile_data.get("preferred_degrees", [])

        user_profile_text = f"{' '.join(user_interests)} {' '.join(user_skills)} {' '.join(preferred_degrees)}"

        # Prepare corpus of program descriptions for NLP semantic matching
        program_texts = []
        catalog_items = []

        for college in self.colleges:
            for prog in college["programs"]:
                text_repr = f"{prog['program_name']} {prog['degree']} {' '.join(prog.get('curriculum_highlights', []))} {' '.join(prog.get('specializations', []))} {college['college_name']} {college['type']}"
                program_texts.append(text_repr)
                catalog_items.append((college, prog))

        # TF-IDF Cosine Similarity for interest & skill matching
        vectorizer = TfidfVectorizer(stop_words='english')
        tfidf_matrix = vectorizer.fit_transform([user_profile_text] + program_texts)
        user_vector = tfidf_matrix[0]
        program_vectors = tfidf_matrix[1:]
        nlp_similarities = cosine_similarity(user_vector, program_vectors)[0]

        dream_list: List[RecommendationItem] = []
        target_list: List[RecommendationItem] = []
        safe_list: List[RecommendationItem] = []

        for idx, (college, prog) in enumerate(catalog_items):
            program_id = prog["program_id"]
            nlp_sim = float(nlp_similarities[idx])
            
            # Find cutoff for this program
            cutoff_entry = next((c for c in self.cutoffs if c["program_id"] == program_id), None)
            min_cutoff = 75.0
            if cutoff_entry and cutoff_entry.get("history"):
                latest = cutoff_entry["history"][0]
                cat_info = latest.get(user_category, latest.get("General", {}))
                min_cutoff = cat_info.get("min_percentile", 75.0)

            # Degree-specific academic check
            degree = prog["degree"]
            academic_fit = 85.0
            if degree in ["B.Tech", "B.Sc"]:
                min_12 = prog.get("min_12th_percentage", 60.0)
                academic_fit = min(100.0, max(40.0, (user_twelfth / min_12) * 85.0))
            else:
                min_ug = prog.get("min_ug_cgpa", 5.5)
                academic_fit = min(100.0, max(40.0, (user_ug_cgpa / min_ug) * 85.0))

            # Entrance score fit calculation
            percentile_diff = user_percentile - min_cutoff
            if percentile_diff >= 5.0:
                cutoff_fit = 95.0
                admission_prob = min(98.0, 85.0 + (percentile_diff * 1.5))
                tier = "Safe"
            elif -4.0 <= percentile_diff < 5.0:
                cutoff_fit = 82.0
                admission_prob = max(55.0, 75.0 + (percentile_diff * 2.5))
                tier = "Target"
            else:
                cutoff_fit = 60.0
                admission_prob = max(20.0, 45.0 + (percentile_diff * 2.0))
                tier = "Dream"

            interests_fit = round(nlp_sim * 100.0, 1)
            skills_fit = round(min(100.0, 60.0 + (nlp_sim * 40.0)), 1)
            
            overall_match = round(
                (0.40 * admission_prob) + 
                (0.30 * interests_fit) + 
                (0.20 * academic_fit) + 
                (0.10 * skills_fit),
                1
            )

            reasons = []
            if nlp_sim > 0.15:
                reasons.append("High alignment with candidate's stated career interests and technical skills.")
            if user_percentile >= min_cutoff:
                reasons.append(f"Candidate's {user_percentile}% percentile comfortably satisfies {user_category} historical cutoff ({min_cutoff}%).")
            else:
                reasons.append(f"Ambitious target: {min_cutoff}% historical cutoff presents a stretch goal for {user_category} quota.")

            placement = prog.get("placement_stats", {})
            reasons.append(f"Impressive {placement.get('placement_rate_pct', 90)}% placement record with {placement.get('average_ctc_lpa', 8.0)} LPA average package.")

            item = RecommendationItem(
                program_id=program_id,
                program_name=prog["program_name"],
                college_id=college["college_id"],
                college_name=college["college_name"],
                degree=prog["degree"],
                tier=tier,
                overall_match_score=overall_match,
                admission_probability=round(admission_prob, 1),
                academic_fit_score=round(academic_fit, 1),
                entrance_cutoff_fit=round(cutoff_fit, 1),
                interests_alignment_score=interests_fit,
                skills_fit_score=skills_fit,
                annual_tuition_fee=float(prog.get("annual_tuition_fee", 100000)),
                average_placement_lpa=float(placement.get("average_ctc_lpa", 8.0)),
                placement_rate_pct=float(placement.get("placement_rate_pct", 90.0)),
                reasons_for_recommendation=reasons,
                career_pathways=self.get_program_career_paths(program_id)
            )

            if tier == "Dream":
                dream_list.append(item)
            elif tier == "Target":
                target_list.append(item)
            else:
                safe_list.append(item)

        # Sort items within each tier by overall match score descending
        dream_list.sort(key=lambda x: x.overall_match_score, reverse=True)
        target_list.sort(key=lambda x: x.overall_match_score, reverse=True)
        safe_list.sort(key=lambda x: x.overall_match_score, reverse=True)

        return RecommendationResponse(
            total_matches=len(catalog_items),
            user_category=user_category,
            user_entrance_percentile=user_percentile,
            dream_options=dream_list,
            target_options=target_list,
            safe_options=safe_list
        )

recommender_engine = CourseRecommenderEngine()

