from pydantic import BaseModel
from typing import List, Optional, Dict, Any

class RecommendationItem(BaseModel):
    program_id: str
    program_name: str
    college_id: str
    college_name: str
    degree: str
    tier: str # "Dream" (High cutoff / stretch), "Target" (Solid match), "Safe" (High certainty)
    overall_match_score: float # 0 - 100%
    admission_probability: float # 0 - 100%
    
    # Matching breakdown
    academic_fit_score: float
    entrance_cutoff_fit: float
    interests_alignment_score: float
    skills_fit_score: float
    
    annual_tuition_fee: float
    average_placement_lpa: float
    placement_rate_pct: float
    reasons_for_recommendation: List[str]
    career_pathways: List[str]

class RecommendationResponse(BaseModel):
    total_matches: int
    user_category: str
    user_entrance_percentile: float
    dream_options: List[RecommendationItem]
    target_options: List[RecommendationItem]
    safe_options: List[RecommendationItem]

