from pydantic import BaseModel
from typing import List, Optional, Dict, Any

class RuleCheckItem(BaseModel):
    rule_name: str
    criterion: str
    student_value: str
    is_satisfied: bool
    details: str
    weight: float = 1.0

class FeatureImportanceItem(BaseModel):
    feature_name: str
    contribution_score: float # positive or negative impact (-1.0 to 1.0)
    description: str

class EligibilityCheckRequest(BaseModel):
    user_id: Optional[int] = None
    program_id: str
    college_id: Optional[str] = None
    
    # Optional direct overrides for real-time sandbox testing
    tenth_percentage: Optional[float] = None
    twelfth_percentage: Optional[float] = None
    ug_cgpa: Optional[float] = None
    ug_degree: Optional[str] = None
    subjects_studied: Optional[List[str]] = None
    entrance_exam_name: Optional[str] = None
    entrance_percentile: Optional[float] = None
    entrance_rank: Optional[int] = None
    reservation_category: Optional[str] = None
    is_pwd: Optional[bool] = None

class EligibilityDecisionResponse(BaseModel):
    program_id: str
    program_name: str
    college_name: str
    degree: str
    status: str # "ELIGIBLE", "CONDITIONAL", "NOT_ELIGIBLE"
    confidence_score: float # 0.0 to 100.0%
    summary_reason: str
    
    # Explainable AI (XAI) deep dive
    rule_checklist: List[RuleCheckItem]
    feature_importances: List[FeatureImportanceItem]
    counterfactual_guidance: List[str]
    applicable_relaxations: List[str]
    applicable_scholarships: List[str]

