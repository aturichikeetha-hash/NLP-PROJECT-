from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from datetime import datetime

class CitationSource(BaseModel):
    doc_id: str
    doc_title: str
    doc_type: str
    section: str
    snippet: str
    relevance_score: float

class RAGQueryRequest(BaseModel):
    user_id: Optional[int] = None
    query: str
    provider: Optional[str] = "local" # "local", "gemini", "openai"
    top_k: int = 4

class RAGQueryResponse(BaseModel):
    query: str
    answer: str
    citations: List[CitationSource]
    model_name: str
    confidence: float
    suggested_followups: List[str]

class SearchResultItem(BaseModel):
    doc_id: str
    title: str
    doc_type: str
    snippet: str
    score: float
    metadata: Dict[str, Any]

class SemanticSearchResponse(BaseModel):
    query: str
    total_results: int
    results: List[SearchResultItem]

