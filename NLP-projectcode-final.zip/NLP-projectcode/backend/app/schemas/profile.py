from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime

class UserBase(BaseModel):
    email: str
    full_name: str
    role: str = "applicant"

class UserCreate(UserBase):
    pass

class UserResponse(UserBase):
    id: int
    created_at: datetime
    class Config:
        from_attributes = True

class AcademicProfileBase(BaseModel):
    tenth_percentage: float = Field(default=85.0, ge=0.0, le=100.0)
    twelfth_percentage: float = Field(default=88.5, ge=0.0, le=100.0)
    ug_cgpa: float = Field(default=8.2, ge=0.0, le=10.0)
    ug_degree: str = "B.Sc Mathematics"
    subjects_studied: List[str] = ["Mathematics", "Physics", "Chemistry", "Computer Science"]
    
    entrance_exam_name: str = "JEE Main"
    entrance_score: float = 145.0
    entrance_percentile: float = 93.8
    entrance_rank: int = 18400
    
    reservation_category: str = "General"  # General, OBC-NCL, SC, ST, EWS
    is_pwd: bool = False
    state_domicile: str = "Home State"
    annual_family_income: float = 650000.0
    
    career_interests: List[str] = ["Artificial Intelligence", "Data Science", "Software Engineering"]
    skills: List[str] = ["Python", "Algorithms", "Mathematics", "Problem Solving"]
    preferred_locations: List[str] = ["Metro Campus", "Tech Corridor"]
    preferred_degrees: List[str] = ["B.Tech", "MCA"]

class AcademicProfileCreate(AcademicProfileBase):
    user_id: int

class AcademicProfileUpdate(AcademicProfileBase):
    pass

class AcademicProfileResponse(AcademicProfileBase):
    id: int
    user_id: int
    updated_at: datetime
    class Config:
        from_attributes = True

