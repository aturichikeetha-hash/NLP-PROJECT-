import json
from typing import List, Dict, Any
from app.config import DATA_DIR
from app.rag.vector_store import hybrid_vector_store

class DocumentIndexer:
    def __init__(self):
        self.indexed_chunks: List[Dict[str, Any]] = []

    def build_and_load_index(self):
        chunks: List[Dict[str, Any]] = []

        # 1. Index Admission Policies
        with open(DATA_DIR / "admission_policies.json", "r", encoding="utf-8") as f:
            policies = json.load(f)
            for pol in policies:
                content = (
                    f"Policy Title: {pol['title']}. Category: {pol['category']}. "
                    f"Degree: {pol['degree']}. Description: {pol['description']}. "
                    f"Mandatory Subjects: {', '.join(pol['rules'].get('mandatory_subjects', []))}. "
                    f"Minimum General Marks: {pol['rules'].get('min_aggregate_marks_general', 'N/A')}%. "
                    f"Minimum Reserved Marks: {pol['rules'].get('min_aggregate_marks_reserved', 'N/A')}%. "
                    f"Accepted Entrance Exams: {', '.join(pol['rules'].get('entrance_exams', []))}."
                )
                chunks.append({
                    "doc_id": pol["id"],
                    "title": pol["title"],
                    "doc_type": "policy",
                    "section": f"Eligibility & Regulations: {pol['degree']}",
                    "content": content,
                    "snippet": pol["description"],
                    "keywords": [pol["degree"], pol["category"], "eligibility", "admission", "regulations", "rules"]
                })

        # 2. Index Colleges and Programs
        with open(DATA_DIR / "colleges_and_programs.json", "r", encoding="utf-8") as f:
            colleges = json.load(f)
            for col in colleges:
                for prog in col["programs"]:
                    content = (
                        f"College: {col['college_name']} ({col['type']}), Location: {col['location']}. "
                        f"Accreditation: {col['accreditation']}, NIRF Rank: {col['nirf_rank']}. "
                        f"Program: {prog['program_name']} ({prog['degree']}), Duration: {prog['duration_years']} years. "
                        f"Total Seats: {prog['total_seats']}, Annual Tuition Fee: INR {prog['annual_tuition_fee']:,}. "
                        f"Eligibility: {prog['eligibility_summary']}. "
                        f"Placements: Average Package INR {prog['placement_stats']['average_ctc_lpa']} LPA, "
                        f"Highest Package INR {prog['placement_stats']['highest_ctc_lpa']} LPA, "
                        f"Placement Rate: {prog['placement_stats']['placement_rate_pct']}%. "
                        f"Top Recruiters: {', '.join(prog['placement_stats']['top_recruiters'])}. "
                        f"Specializations: {', '.join(prog.get('specializations', []))}."
                    )
                    chunks.append({
                        "doc_id": prog["program_id"],
                        "title": f"{prog['program_name']} - {col['college_name']}",
                        "doc_type": "program",
                        "section": f"Program Overview & Placements",
                        "content": content,
                        "snippet": f"{prog['program_name']} at {col['college_name']}: Fee INR {prog['annual_tuition_fee']:,}/yr, Avg CTC {prog['placement_stats']['average_ctc_lpa']} LPA.",
                        "keywords": [prog["degree"], col["college_name"], "placements", "fee", "seats", "curriculum"]
                    })

        # 3. Index Scholarships & Fee Waivers
        with open(DATA_DIR / "scholarships_and_fees.json", "r", encoding="utf-8") as f:
            scholarships = json.load(f)
            for sch in scholarships:
                content = (
                    f"Scholarship Scheme: {sch['name']}. Provider: {sch['provider']}. "
                    f"Target Category: {sch['target_category']}. Benefit: {sch['benefit']}. "
                    f"Income Limit: Family income below INR {sch['eligibility_criteria']['family_income_limit_lpa']} LPA. "
                    f"Applicable Programs: {', '.join(sch['eligibility_criteria']['applicable_degrees'])}. "
                    f"Required Documents: {', '.join(sch['required_documents'])}. "
                    f"Details: {sch['description']}"
                )
                chunks.append({
                    "doc_id": sch["scholarship_id"],
                    "title": sch["name"],
                    "doc_type": "scholarship",
                    "section": f"Financial Aid & Quota Assistance",
                    "content": content,
                    "snippet": f"{sch['name']}: {sch['benefit']} for {sch['target_category']}.",
                    "keywords": ["scholarship", "financial aid", "fee waiver", "EWS", "SC", "ST", "OBC", "concession", "TFWS"]
                })

        # 4. Index Career Pathways
        with open(DATA_DIR / "career_paths.json", "r", encoding="utf-8") as f:
            careers = json.load(f)
            for cp in careers:
                roles_desc = " | ".join([f"{r['title']} ({', '.join(r['key_skills'])})" for r in cp.get("primary_career_roles", [])])
                content = (
                    f"Career Guidance for {cp['program_name']} ({cp['degree']}). "
                    f"Industry Demand: {cp['industry_demand']}. "
                    f"Fresher Salary Range: {cp['fresher_salary_range']}, Mid-Career Salary: {cp['mid_salary_range']}. "
                    f"Key Career Roles: {roles_desc}. "
                    f"Higher Education Pathways: {', '.join(cp.get('higher_education_options', []))}. "
                    f"Recommended Professional Certifications: {', '.join(cp.get('recommended_certifications', []))}."
                )
                chunks.append({
                    "doc_id": f"CAREER-{cp['program_id']}",
                    "title": f"Career Pathways & Scope for {cp['program_name']}",
                    "doc_type": "career",
                    "section": "Career Outlook & Certifications",
                    "content": content,
                    "snippet": f"Career Scope for {cp['program_name']}: Fresher CTC {cp['fresher_salary_range']}, Roles: {', '.join([r['title'] for r in cp['primary_career_roles'][:2]])}.",
                    "keywords": ["career", "jobs", "salary", "certifications", "higher education", "M.Tech", "MBA", "SDE"]
                })

        self.indexed_chunks = chunks
        hybrid_vector_store.index_documents(chunks)
        print(f"[RAG Indexer] Successfully indexed {len(chunks)} knowledge chunks into Hybrid Vector Store.")
        return len(chunks)

document_indexer = DocumentIndexer()

