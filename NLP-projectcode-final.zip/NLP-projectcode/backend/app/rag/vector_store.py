import numpy as np
from typing import List, Dict, Any, Tuple
from rank_bm25 import BM25Okapi
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class HybridVectorStore:
    def __init__(self):
        self.chunks: List[Dict[str, Any]] = []
        self.corpus_texts: List[str] = []
        self.bm25: BM25Okapi = None
        self.vectorizer: TfidfVectorizer = None
        self.dense_matrix = None

    def index_documents(self, chunks: List[Dict[str, Any]]):
        self.chunks = chunks
        self.corpus_texts = [f"{c['title']} {c['content']} {' '.join(c.get('keywords', []))}" for c in chunks]
        
        # 1. Initialize BM25 Index
        tokenized_corpus = [doc.lower().split() for doc in self.corpus_texts]
        self.bm25 = BM25Okapi(tokenized_corpus)

        # 2. Initialize Dense TF-IDF Matrix with n-grams
        self.vectorizer = TfidfVectorizer(
            ngram_range=(1, 2),
            stop_words='english',
            sublinear_tf=True
        )
        self.dense_matrix = self.vectorizer.fit_transform(self.corpus_texts)

    def search(self, query: str, top_k: int = 4, dense_weight: float = 0.6) -> List[Tuple[Dict[str, Any], float]]:
        if not self.chunks or not self.bm25 or not self.vectorizer:
            return []

        # 1. Dense Cosine Scores
        query_vec = self.vectorizer.transform([query])
        dense_scores = cosine_similarity(query_vec, self.dense_matrix)[0]

        # 2. BM25 Keyword Scores
        tokenized_query = query.lower().split()
        bm25_raw_scores = np.array(self.bm25.get_scores(tokenized_query))
        bm25_max = np.max(bm25_raw_scores) if np.max(bm25_raw_scores) > 0 else 1.0
        bm25_normalized = bm25_raw_scores / bm25_max

        # 3. Hybrid Combination: (dense_weight * Dense) + ((1 - dense_weight) * BM25)
        hybrid_scores = (dense_weight * dense_scores) + ((1.0 - dense_weight) * bm25_normalized)

        # Get Top-K indices
        top_indices = np.argsort(hybrid_scores)[::-1][:top_k]

        results = []
        for idx in top_indices:
            score = float(hybrid_scores[idx])
            results.append((self.chunks[idx], round(score, 4)))

        return results

hybrid_vector_store = HybridVectorStore()

