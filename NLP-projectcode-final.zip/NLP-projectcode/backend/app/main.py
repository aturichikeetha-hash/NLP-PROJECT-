from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from app.config import settings
from app.database import engine, Base
import app.models # ensure all models are registered
from app.rag.document_indexer import document_indexer

from app.routers import (
    auth,
    profile,
    eligibility,
    recommendation,
    rag_advisor,
    document_verify,
    career,
    analytics,
    knowledge
)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # 1. Initialize DB tables
    Base.metadata.create_all(bind=engine)
    print("[Startup] Database initialized successfully.")
    
    # 2. Build & Load RAG Vector Search Index
    indexed_count = document_indexer.build_and_load_index()
    print(f"[Startup] RAG Knowledge Base ready with {indexed_count} indexed chunks.")
    
    yield
    print("[Shutdown] Cleaning up resources.")

app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    description="Intelligent College Admission Decision Support System Using Large Language Models, RAG, and Explainable AI (IEEE Spec).",
    lifespan=lifespan
)

# Enable CORS for frontend integration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount API Routers
app.include_router(auth.router, prefix=settings.API_V1_STR)
app.include_router(profile.router, prefix=settings.API_V1_STR)
app.include_router(eligibility.router, prefix=settings.API_V1_STR)
app.include_router(recommendation.router, prefix=settings.API_V1_STR)
app.include_router(rag_advisor.router, prefix=settings.API_V1_STR)
app.include_router(document_verify.router, prefix=settings.API_V1_STR)
app.include_router(career.router, prefix=settings.API_V1_STR)
app.include_router(analytics.router, prefix=settings.API_V1_STR)
app.include_router(knowledge.router, prefix=settings.API_V1_STR)

@app.get("/")
def root():
    return {
        "status": "ONLINE",
        "system": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "docs_url": "/docs",
        "api_v1": settings.API_V1_STR
    }

